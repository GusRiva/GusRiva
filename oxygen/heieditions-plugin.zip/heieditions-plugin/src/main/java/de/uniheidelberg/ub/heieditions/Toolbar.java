package de.uniheidelberg.ub.heieditions;

import de.uniheidelberg.ub.heieditions.abbr.ActionAbbr;
import de.uniheidelberg.ub.heieditions.entities.ActionEntities;
import de.uniheidelberg.ub.heieditions.lb.ActionLb;
import de.uniheidelberg.ub.heieditions.lb.OpenPreferences;
import de.uniheidelberg.ub.heieditions.lb.OptionPage;
import de.uniheidelberg.ub.heieditions.newxmldoc.newDocument;
import de.uniheidelberg.ub.heieditions.numbering.ActionNumbering;
import de.uniheidelberg.ub.heieditions.linecoords.ActionLineCoords;
import de.uniheidelberg.ub.heieditions.reg.ActionReg;
import de.uniheidelberg.ub.heieditions.tokenize.ActionJoinToken;
import de.uniheidelberg.ub.heieditions.tokenize.ActionSplitToken;
import de.uniheidelberg.ub.heieditions.tokenize.ActionTokenizer;
import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.PluginWorkspaceProvider;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;
import ro.sync.exml.workspace.api.standalone.ToolbarComponentsCustomizer;
import ro.sync.exml.workspace.api.standalone.ToolbarInfo;
import ro.sync.exml.workspace.api.standalone.ui.SplitMenuButton;
import ro.sync.exml.workspace.api.standalone.ui.ToolbarButton;

import javax.swing.*;
import java.net.URL;
import java.util.List;

public class Toolbar implements WorkspaceAccessPluginExtension {
    private StandalonePluginWorkspace workspace;

    @Override
    public void applicationStarted(StandalonePluginWorkspace pluginWorkspaceAccess) {
        this.workspace = pluginWorkspaceAccess;
        pluginWorkspaceAccess.addToolbarComponentsCustomizer(new ToolbarComponentsCustomizer() {
            @Override
            public void customizeToolbar(ToolbarInfo toolbarInfo) {
                if (toolbarInfo.getToolbarID().equals("HeieditionsToolbar")) {
                    /* LB */
                    URL iconURL = getClass().getResource("/images/line_beginnings.png");
                    ImageIcon icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    /*URL iconURL2 = getClass().getResource("/images/line_beginnings@2x.png");
                    ImageIcon icon2 = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL2);*/
                    ToolbarAction actionLb = new ToolbarAction("Add <lb> + @n\nAdds an lb at newlines (optional with @n)\n\nctrl + shift + b",
                            new ActionLb(workspace)
                            ,icon);
                    SplitMenuButton lbButton = new SplitMenuButton(
                            null,
                            icon,
                            false,
                            false,
                            false,
                            false
                    );
                    OpenPreferences openPreferences = new OpenPreferences("  Options and help for this action.", OptionPage.KEY, pluginWorkspaceAccess);
                    List listActions = List.of(openPreferences);
                    lbButton.setMenuActions(listActions);
                    lbButton.setCurrentAction(actionLb);

                    /* ENTITIES */
                    iconURL = getClass().getResource("/images/restore_entities.png");
                    icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    /*iconURL = getClass().getResource("/images/restore_entities@2x.png");
                    icon2 = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);*/
                    ToolbarAction actionEntities = new ToolbarAction("Restore Entities and Prologue", new ActionEntities(workspace) ,icon);
                    ToolbarButton entitiesButton = new ToolbarButton(actionEntities, false);

                    /* TOKENIZE - Split Token - Join Token */
                    SplitMenuButton tokenizeButton = new SplitMenuButton(
                            null,
                            null,
                            false,
                            true,
                            false,
                            true
                    );
                    iconURL = getClass().getResource("/images/tokenize.png");
                    icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    ToolbarAction actionTokenize = new ToolbarAction("Tokenize content of current element", new ActionTokenizer(workspace) ,icon);

                    iconURL = getClass().getResource("/images/split_words.png");
                    icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    ToolbarAction actionSplit = new ToolbarAction("Split current token", new ActionSplitToken(workspace) ,icon);

                    iconURL = getClass().getResource("/images/join_words.png");
                    icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    ToolbarAction actionJoin = new ToolbarAction("Join tokens", new ActionJoinToken(workspace) ,icon);


                    listActions = List.of(actionTokenize, actionSplit, actionJoin);
                    tokenizeButton.setMenuActions(listActions);
                    tokenizeButton.setCurrentAction(actionTokenize);




                    /* NUMBERING */
                    iconURL = getClass().getResource("/images/number.png");
                    icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    /*iconURL = getClass().getResource("/images/number@2x.png");
                    icon2 = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);*/
                    ToolbarAction actionNumbering = new ToolbarAction("Add @ attribute to elements\nctrl + shift + n", new ActionNumbering(workspace) ,icon);
                    ToolbarButton numberingButton = new ToolbarButton(actionNumbering, false);


                    /* ABBREVIATUR */
                    iconURL = getClass().getResource("/images/ex.png");
                    icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    ToolbarAction actionAbbr = new ToolbarAction("Abbreviation Expansion", new ActionAbbr(workspace) ,icon);
                    ToolbarButton exButton = new ToolbarButton(actionAbbr, false);

                    /* REGULARISIERUNG */
                    iconURL = getClass().getResource("/images/reg.png");
                    icon = (ImageIcon) PluginWorkspaceProvider.getPluginWorkspace().getImageUtilities().loadIcon(iconURL);
                    ToolbarAction actionReg = new ToolbarAction("Regularisation", new ActionReg(workspace) ,icon);
                    ToolbarButton regButton = new ToolbarButton(actionReg, false);



                    /* New Document by Template */
                    ToolbarAction actionNewDocument = new ToolbarAction("Create new Document (Template)", new newDocument(workspace) ,icon);
                    ToolbarButton newdocumentButton = new ToolbarButton(actionNewDocument, false);

                    /* PageXML from eScriptorium Align in Facsimile Element */
                    ToolbarAction actionAlign = new ToolbarAction("Create Line Zones", new ActionLineCoords(workspace), icon);
                    ToolbarButton actionAlignButton = new ToolbarButton(actionAlign, false);

                    /* PUT TOGETHER */
                    toolbarInfo.setComponents(new JComponent[]{
                            entitiesButton,
                            lbButton,
                            numberingButton,
                            tokenizeButton,
                            exButton,
                            regButton,
                            /*actionAlignButton,*/
                            /*newdocumentButton*/
                    });
                }
            }


        });
    }

    @Override
    public boolean applicationClosing() {
        return true;
    }
}
