package de.uniheidelberg.ub.heieditions.numbering;

import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.options.WSOptionsStorage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

public class WorkspaceAccess implements WorkspaceAccessPluginExtension {
    private StandalonePluginWorkspace workspace;
    public static String OPTION_ELEMENT = "HEIED_NUM_ELEMENT"; /* Element to add n attribute to*/
    public static String OPTION_INUMBER = "HEIED_NUM_INUMBER"; /* last selected intial number */
    public static String OPTION_INCREMENT = "HEIED_NUM_INCREMENT";  /* increment units or decimals */
    @Override
    public void applicationStarted(StandalonePluginWorkspace pluginWorkspaceAccess) {
        this.workspace = pluginWorkspaceAccess;
        //  PREFERENCES OPTION INIT
        WSOptionsStorage optionsStorage = workspace.getOptionsStorage();
        String optionAskStatus = optionsStorage.getOption(OPTION_ELEMENT, "unset");
        if (optionAskStatus.equals("unset")){optionsStorage.setOption(OPTION_ELEMENT, "lb");}
        String optionDecStatus = optionsStorage.getOption(OPTION_INUMBER, "unset");
        if (optionDecStatus.equals("unset")){optionsStorage.setOption(OPTION_INUMBER, "1");}
    }

    @Override
    public boolean applicationClosing() {
        return true;
    }
}
