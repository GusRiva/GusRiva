package de.uniheidelberg.ub.heieditions.lb;

import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class OpenPreferences extends AbstractAction {
    private final StandalonePluginWorkspace workspace;
    private final String pageKey;

    public OpenPreferences(String name, String pageKey, StandalonePluginWorkspace workspaceAccess) {
        super(name);
        this.workspace = workspaceAccess;
        this.pageKey = pageKey;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        if (currentEditorAccess == null) {
            return;
        }
        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        if (!(currentPage instanceof WSXMLTextEditorPage)) {
            return;
        }

        workspace.showPreferencesPages(new String[]{pageKey}, pageKey, true);

    }
}
