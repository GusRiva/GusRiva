package de.uniheidelberg.ub.heieditions;

import ro.sync.exml.plugin.Plugin;
import ro.sync.exml.plugin.PluginDescriptor;

public class HeieditionsPlugin extends Plugin{
    private static de.uniheidelberg.ub.heieditions.HeieditionsPlugin instance = null;

    public HeieditionsPlugin(PluginDescriptor pluginDescriptor) {
        super(pluginDescriptor);
        if (instance != null) {
            throw new IllegalStateException("Already instantiated!");
        }
        instance = this;
    }
    public static HeieditionsPlugin getInstance(){
        return  instance;
    };
}
