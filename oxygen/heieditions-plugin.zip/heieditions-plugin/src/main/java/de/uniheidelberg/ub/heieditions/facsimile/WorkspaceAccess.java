package de.uniheidelberg.ub.heieditions.facsimile;

import org.apache.xerces.dom.ElementNSImpl;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.XPathException;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;
import ro.sync.exml.workspace.api.standalone.ViewComponentCustomizer;
import ro.sync.exml.workspace.api.standalone.ViewInfo;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WorkspaceAccess implements WorkspaceAccessPluginExtension {
    private StandalonePluginWorkspace workspace;

    private JPanel mainPanel;
    private JButton updateButton;
    private JLabel imageLabel;

    @Override
    public void applicationStarted(StandalonePluginWorkspace pluginWorkspaceAccess) {
        workspace = pluginWorkspaceAccess;
        workspace.addViewComponentCustomizer(new ViewComponentCustomizer() {
            @Override
            public void customizeView(ViewInfo viewInfo) {
                if (!"facsimileView".equals(viewInfo.getViewID())) {return;}

                mainPanel = new JPanel();
                mainPanel.setLayout(new BorderLayout());

                updateButton = new JButton("Update");
                updateButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        loadImageFromURL("https://digi.ub.uni-heidelberg.de/diglit/sbb-pk_mgf1062_foll1-35/0001");
                    }
                });

                imageLabel = new JLabel("Label");
                imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

                mainPanel.add(updateButton, BorderLayout.NORTH);
                mainPanel.add(imageLabel, BorderLayout.CENTER);

                viewInfo.setComponent(mainPanel);

            }
        });

    }

    @Override
    public boolean applicationClosing() {
        return true;
    }

    private void loadImageFromURL(String urlString) {
        try {
            URL url = new URL(urlString);
            BufferedImage img = ImageIO.read(url);
            ImageIcon icon = new ImageIcon(img);
            imageLabel.setIcon(icon);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}