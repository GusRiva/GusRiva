package de.uniheidelberg.ub.heieditions;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;

public class heiEditionsEntityResolver implements EntityResolver {
    private static final String ENTITIES = "<!ENTITY combgrave \"&#x0300;\">\n" +
            "<!ENTITY combacute \"&#x0301;\">\n" +
            "<!ENTITY combdblac \"&#x030B;\">\n" +
            "<!ENTITY combcirc \"&#x0302;\">\n" +
            "<!ENTITY combbreve \"&#x0306;\">\n" +
            "<!ENTITY combdot \"&#x0307;\">\n" +
            "<!ENTITY combuml \"&#x0308;\">\n" +
            "<!ENTITY combcomma \"&#x0313;\">\n" +
            "<!ENTITY iuml \"<g ref='char:iuml'>&#x0313;</g>\">\n" +
            "<!ENTITY asup \"&#x0363;\">\n" +
            "<!ENTITY esup \"&#x0364;\">\n" +
            "<!ENTITY isup \"&#x0365;\">\n" +
            "<!ENTITY inodotsup \"<g ref='char:inodotsup'>&#xF02F;</g>\">\n" +
            "<!ENTITY osup \"&#x0366;\">\n" +
            "<!ENTITY usup \"&#x0367;\">\n" +
            "<!ENTITY vsup \"&#x036E;\">\n" +
            "<!ENTITY diagdots \"<g ref='char:diagdots'>&#x0308;</g>\">\n" +
            "<!ENTITY cauda \"<g ref='char:cauda'>&#x0328;</g>\">";
    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
        // Implement your custom entity resolution logic here
        // You can return an InputSource with the content of the entity

        // For example, return a custom string for a specific systemId

        return new InputSource(new StringReader(ENTITIES));


    }
}