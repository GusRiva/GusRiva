package de.uniheidelberg.ub.heieditions.tokenize;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import java.awt.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static de.uniheidelberg.ub.heieditions.Utils.replaceSelection;

public class ActionJoinToken implements WorskspaceAction {
    private final StandalonePluginWorkspace workspace;
    private final Pattern pattern = Pattern.compile("^(<w[^>]*>.*)</w>(.*)<w[^>]*>?(.*</w>)$", Pattern.DOTALL);
    public ActionJoinToken(StandalonePluginWorkspace workspace) {this.workspace = workspace; }

    @Override
    public void performAction() {
        WSEditor editorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        WSXMLTextEditorPage editorPage = (WSXMLTextEditorPage) editorAccess.getCurrentPage();
        JTextArea textComponent = (JTextArea) editorPage.getTextComponent();
        String selection = editorPage.getSelectedText();
        Component parentFrame = (Component) editorAccess.getComponent();

        if (selection == null) {
            JOptionPane.showMessageDialog(parentFrame,
                    "Must select something.",
                    "Error",
                    JOptionPane.PLAIN_MESSAGE);
            return;
        }

        Matcher matcher = pattern.matcher(selection);

        if (!matcher.matches()) {
            JOptionPane.showMessageDialog(parentFrame,
                    "You must select at least two full tokens and no extra elements.",
                    "Error",
                    JOptionPane.PLAIN_MESSAGE);
            return;
        }

        boolean match = true;
        int limit = 0;
        while (match == true) {
            if (limit == 10) {
                JOptionPane.showMessageDialog(parentFrame,
                        "Don't select more than 10 tokens to join.",
                        "Too many tokens",
                        JOptionPane.PLAIN_MESSAGE);
                return;
            }
            selection = replaceToken(selection);
            limit += 1;
            matcher = pattern.matcher(selection);
            if (!matcher.matches()){
                match = false;
            }
        }

        selection = selection.replaceAll("[\n\s]*<c> </c>[\n\s]*", " ");


        int selectionStart = textComponent.getSelectionStart();
        replaceSelection(textComponent, selection, selectionStart);
    }

    private String replaceToken(String input){
        Matcher matcher = pattern.matcher(input);
        String result = matcher.replaceAll("$1$2$3");
        return result;
    }
}
