package de.uniheidelberg.ub.heieditions.newxmldoc;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import org.w3c.dom.*;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class newDocument implements WorskspaceAction {
    private final StandalonePluginWorkspace workspace;
    public newDocument(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
    }


    @Override
    public void performAction() {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.PAGE_AXIS));
        Insets textInset = new Insets(2,2,2,2);

        JTextField fileNameField = new JTextField(5);
        fileNameField.setText("");
        fileNameField.setMargin(textInset);

        JTextField signaturField = new JTextField(5);
        signaturField.setText("");
        signaturField.setMargin(textInset);

        inputPanel.add(new JLabel("Datei Name (ohne relau_id):"));
        inputPanel.add(fileNameField);
        inputPanel.add(Box.createVerticalStrut(15)); // a spacer
        inputPanel.add(new JLabel("Signatur:"));
        inputPanel.add(signaturField);

        Component parentFrame = (Component) currentEditorAccess.getComponent();
        int input = JOptionPane.showConfirmDialog(
                parentFrame,
                inputPanel,
                "Neue Datei anlegen?",
                JOptionPane.OK_CANCEL_OPTION);

        if (input != JOptionPane.OK_OPTION) {
            return;
        }

        String fileName = fileNameField.getText();
        fileName = fileName.replace(" ", "-");
        fileName = fileName.replace("(", "-");
        fileName = fileName.replace(")", "-");
        String signatur = signaturField.getText();

        URL[] location = workspace.getAllEditorLocations(PluginWorkspace.MAIN_EDITING_AREA);
        if (location == null || location.length == 0) {
            System.out.println("Null");
            return;
        }

        URI fileUri = null;
        try {
            fileUri = location[0].toURI();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        Path filePath = Paths.get(fileUri);
        
        Path parentFolder = filePath.getParent();
        File parentFolderFile = parentFolder.toFile();
        File[] allFiles = parentFolderFile.listFiles();
        if (allFiles == null){
            return;
        }

        Set<Integer> allIds = new HashSet<>();
        Integer maxNumber = 0;
        for (int i = 0; i < allFiles.length; i++) {
            File child = allFiles[i];
            String name = child.getName();
            Pattern regex = Pattern.compile("\\((\\d+)\\).xml");
            Matcher matcher = regex.matcher(name);
            while (matcher.find()) {
                Integer number = Integer.valueOf(matcher.group(1));
                if (allIds.contains(number)){
                    System.out.println("Repeated ID: " + number);
                }
                if (number > maxNumber){
                    maxNumber = number;
                }
            }
        }
        int newNumber = maxNumber + 1;

        try {
            /*File inputFile = new File(getClass().getResource("xml/authentik.xml").toString());*/
            File inputFile = new File(getClass().getResource("/templates/authentik.xml").getFile());

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            docFactory.setNamespaceAware(true);
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(inputFile);

            // Create an XPath object with a custom NamespaceContext
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();
            xpath.setNamespaceContext(new NamespaceContext() {
                @Override
                public String getNamespaceURI(String prefix) {
                    if ("tei".equals(prefix)) {
                        return "http://www.tei-c.org/ns/1.0";
                    }
                    // Add more namespaces here if needed
                    return XMLConstants.NULL_NS_URI;
                }

                @Override
                public String getPrefix(String namespaceURI) {
                    // This is not needed for this example
                    return null;
                }

                @Override
                public Iterator<String> getPrefixes(String namespaceURI) {
                    // This is not needed for this example
                    return null;
                }
            });

            // Find the <title> element and modify its content
            XPathExpression titleExpression = xpath.compile("//tei:title");
            NodeList titleNodes = (NodeList) titleExpression.evaluate(doc, XPathConstants.NODESET);
            for (int i = 0; i < titleNodes.getLength(); i++) {
                Element titleElement = (Element) titleNodes.item(i);
                Text newText = doc.createTextNode("Reliquienauthentik");
                Element idnoElement = doc.createElementNS("http://www.tei-c.org/ns/1.0","idno");
                idnoElement.setTextContent(String.valueOf(newNumber));
                Text signaturInTitle = doc.createTextNode(": " + signatur);
                titleElement.appendChild(newText);
                titleElement.appendChild(idnoElement);
                titleElement.appendChild(signaturInTitle);

            }

            // Define the file path and name

            String newFilePath = parentFolder + "/"+ fileName +"(" + newNumber + ").xml";

            // Create a file object
            File xmlFile = new File(newFilePath);

            // Create a file output stream to save the XML data
            OutputStream outputStream = new FileOutputStream(xmlFile);

            // Use a Transformer to save the modified XML document to the new file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(outputStream);
            transformer.transform(source, result);

            // Close the output stream
            outputStream.close();




            URL fileURL = xmlFile.toURI().toURL();
            workspace.open(fileURL);



        } catch (Exception e) {
            e.printStackTrace();
        }









    }
}
