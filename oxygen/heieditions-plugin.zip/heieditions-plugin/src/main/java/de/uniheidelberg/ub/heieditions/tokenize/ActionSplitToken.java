package de.uniheidelberg.ub.heieditions.tokenize;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import org.apache.xerces.dom.ElementNSImpl;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.text.xml.TextDocumentController;
import ro.sync.exml.workspace.api.editor.page.text.xml.TextOperationException;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.XPathException;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class ActionSplitToken  implements WorskspaceAction {

    private final StandalonePluginWorkspace workspace;
    public ActionSplitToken(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
    }
    @Override
    public void performAction() {
        try {
            splitToken();
        } catch (XPathException e) {
            throw new RuntimeException(e);
        } catch (TextOperationException e) {
            throw new RuntimeException(e);
        }
    }

    private void splitToken() throws XPathException, TextOperationException {
        WSEditor editorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        WSXMLTextEditorPage editorPage = (WSXMLTextEditorPage) editorAccess.getCurrentPage();

        Object[] ancestorsObject = editorPage.evaluateXPath("./ancestor-or-self::*");
        ElementNSImpl[] ancestors = Arrays.copyOf(ancestorsObject, ancestorsObject.length, ElementNSImpl[].class) ;

        int caretInit = editorPage.getCaretOffset();
        int caretEnd = caretInit;

        TextDocumentController documentController = editorPage.getDocumentController();
        boolean foundW = false;
        String leftSide = "";
        String rightSide = "";

        for (int i = 1; i <= ancestors.length; i++) {
            ElementNSImpl ancestor = ancestors[ ancestors.length - i];
            String elementName = ancestor.getNodeName();

            System.out.println(elementName);
            if (foundW == true){
                continue;
            }
            if (elementName.equals("w")){
                foundW = true;
            }
            String startTag = "</" + elementName + ">";
            String endTag = "<" + elementName + ">";
            leftSide = leftSide + startTag;
            rightSide = endTag + rightSide;
            caretEnd += startTag.length();
        }

        if (foundW == false){
            Component parentFrame = (Component) editorAccess.getComponent();
            JOptionPane.showMessageDialog(parentFrame,
                    "Not in a <w> element",
                    "Error",
                    JOptionPane.PLAIN_MESSAGE);
            return;
        }
        documentController.insertXMLFragment(leftSide + rightSide, caretInit);
        editorPage.setCaretPosition(caretEnd);
    }
}
