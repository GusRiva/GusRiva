package de.uniheidelberg.ub.heieditions.reg;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.author.WSAuthorEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import java.awt.*;

import static de.uniheidelberg.ub.heieditions.Utils.replaceSelection;

public class ActionReg implements WorskspaceAction {
    private final StandalonePluginWorkspace workspace;
    public ActionReg(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
    }
    @Override
    public void performAction() {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);

        /* No file open */
        if (currentEditorAccess == null) {
            return;
        }
        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        /* In editor mode or author mode */
        if (!(currentPage instanceof WSXMLTextEditorPage || currentPage instanceof WSAuthorEditorPage)) {
            return;
        }

        /* Editor mode */
        if (currentPage instanceof WSXMLTextEditorPage){
            editorPageAction(currentPage, currentEditorAccess);
        }
    }

    private void editorPageAction(WSEditorPage currentPage,  WSEditor currentEditorAccess){
        WSXMLTextEditorPage textPage = (WSXMLTextEditorPage) currentPage;
        JTextArea textComponent = (JTextArea) textPage.getTextComponent();


        String selection = textComponent.getSelectedText();
        if (null == selection){
            selection = "";
        }
        int selectionStart = textComponent.getSelectionStart();

        Component parentFrame = (Component) currentEditorAccess.getComponent();
        String[] userInput = getUserInput(parentFrame, selection);
        if (userInput[0].equals("1")){
            return;
        }

        String newContent = "<choice><orig>" + userInput[1] + "</orig><reg>" + userInput[2] + "</reg></choice>";

        replaceSelection(textComponent, newContent, selectionStart);
    }

    private String[] getUserInput(Component parentFrame, String selection) {
        String[] result = new String[3];
        result[0] = "1"; /* Default failed option */
        Insets textInset = new Insets(2,2,2,2);
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.PAGE_AXIS));

        JTextField origField = new JTextField(5);
        origField.setText(selection);
        origField.setMargin(textInset);

        JTextField regField = new JTextField(5);
        regField.setText("");
        regField.setMargin(textInset);

        inputPanel.add(new JLabel("orig:"));
        inputPanel.add(origField);
        inputPanel.add(Box.createVerticalStrut(15)); // a spacer
        inputPanel.add(new JLabel("reg:"));
        inputPanel.add(regField);

        int input = JOptionPane.showConfirmDialog(
                parentFrame,
                inputPanel,
                "Regularisierung",
                JOptionPane.OK_CANCEL_OPTION);

        /* Cancel on OptionPane */
        if (input != JOptionPane.OK_OPTION) {
            return result;
        }
        result[0] = "0";
        result[1] = origField.getText();
        result[2] = regField.getText();

        return result;


    }

}
