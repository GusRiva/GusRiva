package de.uniheidelberg.ub.heieditions;


public interface WorskspaceAction {
    public void performAction();
}
