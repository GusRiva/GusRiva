package de.uniheidelberg.ub.heieditions.entities;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.text.WSTextEditorPage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ActionEntities implements WorskspaceAction{
    private final StandalonePluginWorkspace workspace;
    public ActionEntities(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
    }

    final String DTD = "<!DOCTYPE TEI\n" +
            "[\n" +
            "<!ENTITY % heiEDITIONS_entities SYSTEM \"https://digi.ub.uni-heidelberg.de/schema/tei/heiEDITIONS/declarations/heieditions-entities.txt\">\n" +
            "%heiEDITIONS_entities; ]>\n";

    @Override
    public void performAction()  {
        try {


        // get the current entity declaration over the network (keys: expanded strings, values: entity names):
        HashMap<String, String> entityDeclarations;
        entityDeclarations = getEntityDeclarations();

        if (entityDeclarations.isEmpty()){return;}

        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        WSTextEditorPage page = (WSTextEditorPage) currentEditorAccess.getCurrentPage();
        Component parentComponent = (Component) currentEditorAccess.getComponent();
        JFrame parentFrame = (JFrame) workspace.getParentFrame();


        JDialog loadingDialog = new JDialog(parentFrame, "Replacing Entities");
        loadingDialog.setSize(300, 100);
        loadingDialog.setLocationRelativeTo(parentFrame);
        loadingDialog.setVisible(true);

        int caret = page.getCaretOffset();
        Document document = page.getDocument();

        String text = "";


        text = document.getText(0, document.getLength());

        for (Map.Entry<String, String> entry : entityDeclarations.entrySet()) {
            String expand = entry.getKey();
            String ename = entry.getValue();
            String oldText = text;
            text = oldText.replace(expand, "&" + ename + ";");
        }

        text = insertPrologue(text);

        document.remove(0, document.getLength());
        document.insertString(0, text, null);




        page.setCaretPosition(caret);
        loadingDialog.dispose();

        JOptionPane.showMessageDialog(parentComponent, "Action Complete", "Replace Entities", JOptionPane.INFORMATION_MESSAGE);

        } catch (BadLocationException e){
            throw new RuntimeException(e);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private HashMap<String, String> getEntityDeclarations() throws URISyntaxException, IOException, InterruptedException {
        URI url = new URI("https://digi.ub.uni-heidelberg.de/schema/tei/heiEDITIONS/declarations/heieditions-entities.txt");
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(url).build();
        HttpResponse<String> httpResponse = client.send(request, HttpResponse.BodyHandlers.ofString());

        String respBody = httpResponse.body();
        HashMap<String, String> entities = new HashMap<String, String>();
        // a regex pattern matching the single entity declarations:
        Pattern pattern = Pattern.compile("!ENTITY (\\w+) \"(.+)\"");
        // a regex matcher with the previous pattern for the entity declaration file:
        Matcher matcher = pattern.matcher(respBody);
        // a regex pattern matching the hexadecimal number in an entity based on a hexadecimal number:
        Pattern patternCodePoint = Pattern.compile("&#x([\\da-fA-F]+);");
        // a regex pattern matching an entity expansion consisting of a "g" element:
        Pattern patternGContent = Pattern.compile("(<g.*?>)(.+)(</g>)");

        // iterating over single entity declarations:
        while (matcher.find()) {
            String entityName = matcher.group(1);
            String entityExpanded = matcher.group(2);
            // for entities expanded with a "g" element (the assumption is that it is only one single "g" element):
            if (entityExpanded.startsWith("<g")){
                Matcher matcherGContent = patternGContent.matcher(entityExpanded);
                while (matcherGContent.find()) {
                    // extracting the content of the "g" element:
                    String gContent = matcherGContent.group(2);
                    Matcher gContentMatcherCodePoint = patternCodePoint.matcher(gContent);
                    String characterString = null;
                    while (gContentMatcherCodePoint.find()) {
                        // extracting the hexadecimal character number (assuming that the "g" element only contains
                        // exactly one entity based on a hexadecimal number:
                        String codePointString = gContentMatcherCodePoint.group(1);
                        int codePoint = Integer.parseInt(codePointString, 16);
                        char character = (char) codePoint;
                        // string consisting of exactly one character corresponding to the original content of the "g" element:
                        characterString = String.valueOf(character);
                    }
                    // putting the "g" element together with the content replaced by the expanded character string:
                    String stringWithSimpleQuotationMarks = matcherGContent.group(1) + characterString + matcherGContent.group(3);
                    // replacing the single quotation marks used for XML attributes in the entity declaration:
                    String stringWithDoubleQuotationMarks = stringWithSimpleQuotationMarks.replace('\'', '\"');
                    // putting the expansion and the entity name as key and value in the hash map:
                    entities.put(stringWithDoubleQuotationMarks, entityName);
                }
            } else {
                // for entities expanded with a single entity based on a hexadecimal number:
                Matcher matcherCodePoint = patternCodePoint.matcher(entityExpanded);
                while (matcherCodePoint.find()) {
                    // extracting the hexadecimal character number
                    String codePointString = matcherCodePoint.group(1);
                    int codePoint = Integer.parseInt(codePointString, 16);
                    char character = (char) codePoint;
                    // putting the expansion and the entity name as key and value in the hash map:
                    entities.put(String.valueOf(character), entityName);
                }
            }
        }
        return entities;
    }

    public String insertPrologue(String text) {
        if (!text.contains("<?xml version")) {
            StringBuilder sb = new StringBuilder(text);
            sb.insert(0, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            text = sb.toString();
        }

        if (!text.contains("<?xml-model href=\"https://digi.ub.uni-heidelberg.de/schema/tei/heiEDITIONS/tei_hes.rng\"")) {
            text = text.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    , "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                            "<?xml-model href=\"https://digi.ub.uni-heidelberg.de/schema/tei/heiEDITIONS/tei_hes.rng\" type=\"application/xml\" schematypens=\"http://relaxng.org/ns/structure/1.0\"?>\n" +
                            "<?xml-model href=\"https://digi.ub.uni-heidelberg.de/schema/tei/heiEDITIONS/tei_hes.rng\" type=\"application/xml\" schematypens=\"http://purl.oclc.org/dsdl/schematron\"?>");
        }

        if (!text.contains("<!DOCTYPE TEI")) {
            text = text.replace("<TEI", DTD + "\n<TEI");
        }

        return text;
    }
}

