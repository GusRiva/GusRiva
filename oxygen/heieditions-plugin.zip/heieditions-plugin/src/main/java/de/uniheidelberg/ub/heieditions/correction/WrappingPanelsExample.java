package de.uniheidelberg.ub.heieditions.correction;

import javax.swing.*;
import java.awt.*;

public class WrappingPanelsExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Wrapping Panels Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

            for (int panelIndex = 0; panelIndex < 2; panelIndex++) {
                JPanel panel = new JPanel();
                panel.setLayout(new WorkspaceAccess.WrappingFlowLayout(FlowLayout.LEFT, 10, 10)); // Adjust hgap and vgap as needed

                for (int i = 1000; i <= 1010; i++) {
                    JLabel label = new JLabel(Integer.toString(i));
                    panel.add(label);
                }

                JScrollPane scrollPane = new JScrollPane(panel);
                scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

                // Calculate the preferred height for the scroll pane based on four lines of labels
                int lineHeight = panel.getComponent(0).getPreferredSize().height + 10;
                int preferredHeight = lineHeight * 4;
                scrollPane.setPreferredSize(new Dimension(scrollPane.getPreferredSize().width, preferredHeight));
                scrollPane.setMaximumSize(new Dimension(scrollPane.getMaximumSize().width, preferredHeight));

                mainPanel.add(scrollPane);
            }

            frame.getContentPane().add(mainPanel);
            frame.setSize(400, 400); // Set initial frame size
            frame.setLocationRelativeTo(null); // Center the window
            frame.setVisible(true);
        });
    }
}