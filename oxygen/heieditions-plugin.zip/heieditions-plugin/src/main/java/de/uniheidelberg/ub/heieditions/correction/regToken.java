package de.uniheidelberg.ub.heieditions.correction;

import static de.uniheidelberg.ub.heieditions.Utils.normalizeTEISpace;

public class regToken {
    private final String content;
    private String plainText;
    private String html; /* This should be the content of the JLabel, that allows for formatting */
    private int startPosition;
    private int endPosition;
    public regToken(String xmlFragment) {
        this.content = xmlFragment;
        this.plainText = plainText;
        this.html = html;
        this.startPosition = startPosition;
        this.endPosition = endPosition;
    }

    public String getPlainText() {
        String normalizedContent = normalizeTEISpace(this.content);
        return normalizedContent;
    }

    public String getHtmlReg(){
        String result = basicCleaning();
        result = result.replaceAll("<orig>(.*?)</orig>", "");
        result = result.replaceAll("<reg>(.*?)</reg>", "<u style='text-decoration: underline; text-decoration-color:red;'>$1</u>");
        /*System.out.println("REG: " + result);*/
        return result;
    }

    public String getHtmlOrig(){
        String result = basicCleaning();
        result = result.replaceAll("<reg\\b>(.*?)</reg\\b>", "");
        result = result.replaceAll("<orig\\b>(.*?)</orig\\b>", "<u style='text-decoration: underline; text-decoration-color:red;'>$1</u>");
        /*System.out.println(result);*/
        return result;
    }

    private String basicCleaning(){
        String result = normalizeTEISpace(this.content);
        result = result.replaceAll("</?choice\\b/?>", "");
        result = result.replaceAll("</?hi\\b[^>]*/?>", "");
        result = result.replaceAll("</?hi\\b[^>]*/?>", "");
        result = result.replaceAll("<am\\b>(.*?)</am>", "");
        result = result.replaceAll("<ex\\b>(.*?)</ex>", "($1)");
        /*System.out.println(result);*/
        return result;
    }
}
