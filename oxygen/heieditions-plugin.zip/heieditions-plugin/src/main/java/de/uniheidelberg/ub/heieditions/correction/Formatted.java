package de.uniheidelberg.ub.heieditions.correction;

public class Formatted {

    public Formatted() {

    }
}
