package de.uniheidelberg.ub.heieditions.tokenize;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextNodeRange;
import ro.sync.exml.workspace.api.editor.page.text.xml.XPathException;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ActionTokenizer implements WorskspaceAction{
    private final StandalonePluginWorkspace workspace;
    public ActionTokenizer(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
    }

    private final String punctuationCharacters = "\\.:,;\\?!\\(\\)/";
    private final short indent = 4;
    private final String indentString = String.join("", Collections.nCopies(indent, " "));

    @Override
    public void performAction()  {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        if (currentEditorAccess == null) {
            return;
        }
        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        if (!(currentPage instanceof WSXMLTextEditorPage)) {
            return;
        }
        WSXMLTextEditorPage textPage = (WSXMLTextEditorPage) currentPage;
        JTextArea textComponent = (JTextArea) textPage.getTextComponent();

        WSXMLTextNodeRange[] currentElementRanges = new WSXMLTextNodeRange[0];
        try {
            currentElementRanges = textPage.findElementsByXPath(".");
            WSXMLTextNodeRange currentElementRange = currentElementRanges[0];
            // the amount of indent at the start of the current element
            int currentElementIndent = currentElementRange.getStartColumn();
            // offset of the current element start (inclusive):
            int currentElementStartOffset = textPage.getOffsetOfLineStart(currentElementRange.getStartLine())
                    + currentElementRange.getStartColumn() - 1;
            // offset of the current element end (exclusive):
            int currentElementEndOffset = textPage.getOffsetOfLineStart(currentElementRange.getEndLine())
                    + currentElementRange.getEndColumn() - 1;

            WSXMLTextNodeRange[] currentElementChildrenRanges = textPage.findElementsByXPath("./node()");
            // offset of the first child node start (inclusive):
            int firstNodeStartOffset = textPage.getOffsetOfLineStart(currentElementChildrenRanges[0].getStartLine())
                    + currentElementChildrenRanges[0].getStartColumn() - 1;
            // offset of the last child node end (exclusive):
            int lastNodeStartOffset = textPage.getOffsetOfLineStart(currentElementChildrenRanges[currentElementChildrenRanges.length - 1].getEndLine())
                    + currentElementChildrenRanges[currentElementChildrenRanges.length - 1].getEndColumn() - 1;

            // empty string array having the length of the current element children count:
            String[] currentElementChildrenStrings = new String[currentElementChildrenRanges.length];
            for (int i = 0; i < currentElementChildrenRanges.length; i++) {
                WSXMLTextNodeRange currentElementChildRange = currentElementChildrenRanges[i];
                int childStartOffset = textPage.getOffsetOfLineStart(currentElementChildRange.getStartLine())
                        + currentElementChildRange.getStartColumn() -1;
                int childEndOffset = textPage.getOffsetOfLineStart(currentElementChildRange.getEndLine())
                        + currentElementChildRange.getEndColumn() -1;
                String childString = textComponent.getText(childStartOffset, childEndOffset - childStartOffset);
                currentElementChildrenStrings[i] = childString;
            }

            // empty array list for results of the next loop:
            ArrayList<String> whiteSpaceSplitStrings = new ArrayList<>();
            Pattern whiteSpaceSplitPattern = Pattern.compile("\\s+|\\S+");
            Pattern digitPattern = Pattern.compile("\\d+");
            Pattern punctuationPattern = Pattern.compile("[.:,;?!/]+|[^.:,;?!/]+");
            Pattern entityPattern = Pattern.compile("&[a-z]+;");
            Pattern digitPunctuationSplitPattern = Pattern.compile("\\d+|[.:,;?!/]+|[^\\d.:,;?!/]+");
            Pattern letterPattern = Pattern.compile("[^\\d.:,;?!/]+");


            for (String rawString : currentElementChildrenStrings) {
                // if the string contains an element node:
                if (rawString.startsWith("<")) {
                    // copy the element node string unchanged into whiteSpaceSplitStrings:
                    whiteSpaceSplitStrings.add(rawString);
                }
                // otherwise it must be a text node:
                else {
                    Matcher whiteSpaceSplitMatcher = whiteSpaceSplitPattern.matcher(rawString);
                    // Find all matches
                    while (whiteSpaceSplitMatcher.find()) {
                        // Get the matching string
                        String match = whiteSpaceSplitMatcher.group();
                        // if the string consists of whitespaces, replace it with a single whitespace and add it to the new array:
                        if (match.matches("\\s+")) {
                            whiteSpaceSplitStrings.add(" ");
                            continue;
                        }
                        // if the string consists of non-whitespace characters:
                        whiteSpaceSplitStrings.add(match);
                    }
                }
            }

            // empty array list for results of the next loop:
            ArrayList<String> entitySplitStrings = new ArrayList<>();

            for (String rawString : whiteSpaceSplitStrings) {
                // if the string contains an element node or a whitespace node:
                if (rawString.startsWith("<") || rawString.equals(" ")) {
                    // copy the element node string unchanged into whiteSpaceSplitStrings:
                    entitySplitStrings.add(rawString);
                    continue;
                }
                // otherwise it must be a text node yet to be processed:
                Matcher entityMatcher = entityPattern.matcher(rawString);
                int position = 0;
                // find all matches
                while (entityMatcher.find()) {
                    // if the match does not start at $position, append the substring before it to the result array:
                    if (entityMatcher.start() != position) {
                        entitySplitStrings.add(rawString.substring(position, entityMatcher.start()));
                    }
                    // add the match itself to the result array:
                    entitySplitStrings.add(rawString.substring(entityMatcher.start(), entityMatcher.end()));
                    // reset $position to the offset after the match:
                    position = entityMatcher.end();
                }
                // after the last match or if isn't any match, append the rest of $rawString to the result array:
                if (position != rawString.length()) {
                    entitySplitStrings.add(rawString.substring(position));
                }
            }

            // empty array list for results of the next loop:
            ArrayList<String> digitPunctuationSplitStrings = new ArrayList<>();

            for (String rawString : entitySplitStrings) {
                // if the string contains an element node, a whitespace node or an entity:
                if (rawString.startsWith("<") || rawString.equals(" ") || rawString.matches("&[a-z]+;")) {
                    // copy the element node string unchanged into whiteSpaceSplitStrings:
                    digitPunctuationSplitStrings.add(rawString);
                }
                // otherwise it must be a text node yet to be processed:
                else {
                    Matcher digitPunctuationSplitMatcher = digitPunctuationSplitPattern.matcher(rawString);
                    while (digitPunctuationSplitMatcher.find()) {
                        String submatch = digitPunctuationSplitMatcher.group();
                        digitPunctuationSplitStrings.add(submatch);
                    }
                }
            }

            // remove whitespace items if at the beginning or the end of the array:
            if (digitPunctuationSplitStrings.get(0).equals(" ")) {
                digitPunctuationSplitStrings.remove(0);
            }
            if (digitPunctuationSplitStrings.get(digitPunctuationSplitStrings.size() - 1).equals(" ")) {
                digitPunctuationSplitStrings.remove(digitPunctuationSplitStrings.size() - 1);
            }

            // remove whitespace items adjacent to pb/cb/lb/milestone-items
            for (int i = 0; i < digitPunctuationSplitStrings.size(); i++) {
                // if the item is a whitespace item (here it cannot be at the beginning or the end any more)
                if (!digitPunctuationSplitStrings.get(i).equals(" ")) {
                    continue;
                }
                if (
                        (
                                digitPunctuationSplitStrings.get(i - 1).startsWith("<lb")
                                        || digitPunctuationSplitStrings.get(i - 1).startsWith("<cb")
                                        || digitPunctuationSplitStrings.get(i - 1).startsWith("<pb")
                                        ||
                                        (
                                                digitPunctuationSplitStrings.get(i - 1).startsWith("<milestone")
                                                        && (digitPunctuationSplitStrings.get(i - 1).contains("hc:ZoneBeginning")
                                                        || digitPunctuationSplitStrings.get(i - 1).contains("hc:ZoneShift")
                                                        || digitPunctuationSplitStrings.get(i - 1).contains("hc:LineSegmentBeginning")
                                                )
                                        )
                        )
                                ||
                                (digitPunctuationSplitStrings.get(i + 1).startsWith("<lb")
                                        || digitPunctuationSplitStrings.get(i + 1).startsWith("<cb")
                                        || digitPunctuationSplitStrings.get(i + 1).startsWith("<pb")
                                        || (digitPunctuationSplitStrings.get(i + 1).startsWith("<milestone")
                                        &&
                                        (
                                                digitPunctuationSplitStrings.get(i + 1).contains("hc:ZoneBeginning")
                                                        || digitPunctuationSplitStrings.get(i + 1).contains("hc:ZoneShift")
                                                        || digitPunctuationSplitStrings.get(i + 1).contains("hc:LineSegmentBeginning")
                                        )
                                ))
                ) {
                    digitPunctuationSplitStrings.remove(i);
                }
            }

            // empty array list for results of the next loop:
            ArrayList<String> resultStringList = new ArrayList<>();

            for (int i = 0; i < digitPunctuationSplitStrings.size(); i++) {
                String item = digitPunctuationSplitStrings.get(i);
                // Matcher letterMatcher = letterPattern.matcher(item);
                // Matcher digitMatcher = digitPattern.matcher(item);
                // if the item consists of letters:
                if (isLetterLike(item)) {
                    StringBuilder stringBuilder = new StringBuilder(item);
                    // if the item is not the last one:
                    while (
                            i < digitPunctuationSplitStrings.size() - 1
                                    &&
                                    (
                                            isLetterLike(digitPunctuationSplitStrings.get(i + 1))
                                                    ||
                                                    isNonBreakableMilestone(digitPunctuationSplitStrings.get(i + 1))
                                                    ||
                                                    isOtherInWordTag(digitPunctuationSplitStrings.get(i + 1))
                                    )
                    ) {
                        stringBuilder.append(digitPunctuationSplitStrings.get(i + 1));
                        i++;
                    }
                    resultStringList.add("<w>" + stringBuilder.toString() + "</w>");
                }
                //punctuation:
                else if ( item.matches("[" + punctuationCharacters + "]+" )) {
                    resultStringList.add("<pc>" + item + "</pc>");
                }
                // numbers:
                else if (item.matches("\\d+")) {
                    resultStringList.add("<num>" + item + "</num>");
                }
                else if (item.equals(" ")) {
                    resultStringList.add("<c> </c>");
                }
                else {
                    resultStringList.add(item);
                }
            }

            String completeIndentString = indentString + String.join("", Collections.nCopies(currentElementIndent, " "));

            for (int i = 0; i < resultStringList.size(); i++) {
                String indented_item = completeIndentString + resultStringList.get(i) + "\n";
                resultStringList.set(i, indented_item);
            }

            resultStringList.add(0, "\n");
            resultStringList.add(String.join("", Collections.nCopies(currentElementIndent, " ")));

            String concatenatedString = String.join("", resultStringList);

            // replacing all child content:
            textComponent.replaceRange(concatenatedString, firstNodeStartOffset, lastNodeStartOffset);

        } catch (BadLocationException xPathException) {
            xPathException.printStackTrace();
        } catch (XPathException e) {
            throw new RuntimeException(e);
        }

    }

    private boolean isLetterLike(String input) {
        if (input.startsWith("<") || input.matches("\\d+") || input.equals(" ") || input.matches("[" + punctuationCharacters + "]+"))
            return false;
        else
            return true;
    }

    private boolean isNonBreakableMilestone(String input) {
        if (
                ( input.startsWith("<pb") || input.startsWith("<cb") || input.startsWith("<lb") )
                        &&
                        input.contains("break=\"no\"")
                        ||
                        input.startsWith("<milestone")
                                &&
                                ( input.contains("hc:ZoneBeginning") || input.contains("hc:ZoneShift") || input.contains("hc:LineSegmentBeginning") )
                                &&
                                input.contains("break=\"no\"")
        ) { return true; }
        return false;
    }

    private boolean isOtherInWordTag(String input) {
        if (
                ! ( input.startsWith("<pb") || input.startsWith("<cb") || input.startsWith("<lb") )
                        &&
                        ! (
                                input.startsWith("<milestone")
                                        &&
                                        ( input.contains("hc:ZoneBeginning") || input.contains("hc:ZoneShift") || input.contains("hc:LineSegmentBeginning") )
                        )
                        &&
                        ! input.startsWith("<w")
                        &&
                        ! input.startsWith("<pc")
                        &&
                        ! input.startsWith("<!--")
                        &&
                        input.startsWith("<")
        ) {
            return true;
        }
        return false;

    }


}
