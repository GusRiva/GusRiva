package de.uniheidelberg.ub.heieditions.linecoords;

import de.uniheidelberg.ub.heieditions.NamespaceContextHeiEditions;
import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.options.WSOptionsStorage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class ActionLineCoords implements WorskspaceAction {
    private final StandalonePluginWorkspace workspace;
    public ActionLineCoords(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
    }
    @Override
    public void performAction() {

        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        WSOptionsStorage optionsStorage = workspace.getOptionsStorage();
        if (currentEditorAccess == null) {
            return;
        }
        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        if (!(currentPage instanceof WSXMLTextEditorPage)) {
            return;
        }
        WSXMLTextEditorPage textPage = (WSXMLTextEditorPage) currentPage;

        JTextArea textComponent = (JTextArea) textPage.getTextComponent();

        Component parentFrame = (Component) currentEditorAccess.getComponent();

        File defaultFile = new File("/home/gustavo/Dokumente/heiImageViewer/heiImageViewer/examples/iwein_ONB2779");

        File METS = workspace.chooseFile(defaultFile,"Select METS.xml file", new String[]{"xml"}, "METS XMl File",false);

        if (METS == null) {
            return;
        }

        String chosenFilePath = METS.getAbsolutePath();
        String chosenFileDir = METS.getParent();

        InputSource inputSource = new InputSource(chosenFilePath);
        XPath xpath = XPathFactory.newInstance().newXPath();
        xpath.setNamespaceContext(new NamespaceContextHeiEditions());
        NodeList nodes = null;
        try {

            nodes = (NodeList) xpath.evaluate("//mets:fileGrp/mets:file/mets:FLocat", inputSource, XPathConstants.NODESET);
            for (int i = 0; i < nodes.getLength(); i++) {
                Node node = nodes.item(i);
                String pageFileName = node.getAttributes().getNamedItem("xlink:href").getNodeValue();


                Path normalizedPath = Paths.get(chosenFileDir + "/" + pageFileName).normalize();
                String normalizedFilePath = normalizedPath.toAbsolutePath().toString();
                File pageFile = new File(normalizedFilePath);

                if (!pageFile.exists()){
                    System.out.println("File does not exist: " + normalizedFilePath);
                    continue;
                }



                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document document = builder.parse(pageFile);

                // Get the root element
                Node rootNode = document.getDocumentElement();
                System.out.println("Root Node:" + rootNode.getNodeName());
                NodeList textRegions = (NodeList) xpath.evaluate("//TextRegion", rootNode, XPathConstants.NODESET);
                for (int j = 0; j < textRegions.getLength(); j++) {
                    Node textRegion = textRegions.item(j);
                    System.out.println(textRegion.getAttributes().getNamedItem("id"));
                    NodeList textRegionChildren = textRegion.getChildNodes();
                    for (int k = 0; k < textRegionChildren.getLength(); k++) {
                        Node element = textRegionChildren.item(k);
                        if (element.getNodeName() == "Coords"){
                            String textRegionCoords = element.getAttributes().getNamedItem("points").getNodeValue();
                            System.out.println(textRegionCoords);
                            continue;
                        }
                    }


                }


                // Iterate over the children nodes
           /*     if (rootNode.hasChildNodes()) {
                    NodeList children = rootNode.getChildNodes();
                    for (int j = 0; j < children.getLength(); j++) {
                        Node childNode = children.item(j);
                        if (childNode.getNodeName() == "Page"){

                        }

                    }
                }*/


                /*
                InputSource pageInputSource = new InputSource(normalizedFilePath);

                NodeList textLines = (NodeList) xpath.evaluate("//page:TextLine", pageInputSource, XPathConstants.NODESET);
                for (int j = 0; j < textLines.getLength(); j++) {
                    Node line = textLines.item(j);

                    System.out.println(line.getAttributes().getNamedItem("id").getNodeValue());
                }
*/











                /*InputSource pageInputSource = new InputSource(new FileInputStream(pageFile));
                *//*InputSource pageFile = new InputSource(chosenFileDir + "/" + pageFileName);*//*

                NodeList textLines = (NodeList) xpath.evaluate("//page:TextLine", pageFile, XPathConstants.NODESET);
                for (int j = 0; j < textLines.getLength(); j++) {
                    Node line = textLines.item(j);
                    System.out.println(line.getAttributes().getNamedItem("id").getNodeValue());
                }*/

            }
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        }





        /*

        // Handle Open menu item action here
        JFileChooser fileChooser = new JFileChooser();
        *//*fileChooser.setCurrentDirectory(lastChosenFolder);*//*
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            // User selected a file
            JDialog loadingDialog = createLoadingDialog((JFrame) parentFrame);
            Thread loadThread = new Thread(() -> {
                fillZones();
                SwingUtilities.invokeLater(loadingDialog::dispose);
            });
            loadThread.start();
            loadingDialog.setVisible(true);
        }

*/


    }

    private void fillZones() {
        System.out.println("Fill Zones");
        return;
    }

    private static JDialog createLoadingDialog(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Loading", Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        dialog.setSize(200, 100);
        dialog.setLocationRelativeTo(parent);

        JLabel label = new JLabel("Please wait...");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        dialog.getContentPane().add(label);

        return dialog;
    }
}


