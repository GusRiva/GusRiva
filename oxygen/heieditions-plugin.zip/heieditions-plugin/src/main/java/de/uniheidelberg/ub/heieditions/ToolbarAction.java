package de.uniheidelberg.ub.heieditions;

import javax.swing.*;
import java.awt.event.ActionEvent;


public class ToolbarAction extends AbstractAction {
    private final WorskspaceAction action;

    public ToolbarAction(String name, WorskspaceAction action, Icon icon) {
        super(name, icon);
        this.action = action;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        action.performAction();
    }

}
