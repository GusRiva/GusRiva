package de.uniheidelberg.ub.heieditions.lb;

import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.options.WSOptionsStorage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import static de.uniheidelberg.ub.heieditions.lb.Plugin.OPTION_ASKN;
import static de.uniheidelberg.ub.heieditions.lb.Plugin.OPTION_DECIMALS;

/*https://github.com/oxygenxml/oxygen-git-client-addon/blob/master/src/main/java/com/oxygenxml/git/OxygenGitOptionPagePluginExtension.java*/
public class OptionPage extends ro.sync.exml.plugin.option.OptionPagePluginExtension {


    public static final String KEY = "Heieditions_lb";

    private static JCheckBox askLineNumberCheckbox;

    private static JComboBox decimalsCombobox;


    @Override
    public void apply(PluginWorkspace pluginWorkspace) {

    }

    @Override
    public void restoreDefaults() {
        askLineNumberCheckbox.setSelected(true);
        decimalsCombobox.setSelectedIndex(0);
    }

    @Override
    public String getTitle() {
        return "Line Break Plugin";
    }

    @Override
    public JComponent init(final PluginWorkspace pluginWorkspace) {

//      Option on start
        WSOptionsStorage optionsStorage = pluginWorkspace.getOptionsStorage();
        String optionAsknStatus = optionsStorage.getOption(OPTION_ASKN, "1");
        String optionDecimalStatus = optionsStorage.getOption(OPTION_DECIMALS, "1");

//        JComponents
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
        mainPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel textArea = new JLabel("<html><body style='width: 400px'>This tools is used to replace every new-line character with an lb element of TEI.</body></html>");
        JLabel shortcut = new JLabel("<html><body style='width: 400px'><em>Keyboard shortcut:</em> ctrl + shift + b</body></html>");
        Font fontPlain = textArea.getFont().deriveFont(Font.PLAIN);
        textArea.setFont(fontPlain);
        textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        textArea.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(textArea);
        shortcut.setBorder(BorderFactory.createEmptyBorder(10,10,20,10));
        shortcut.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(shortcut);

        askLineNumberCheckbox = new JCheckBox("Ask for initial line number");
        askLineNumberCheckbox.setSelected(optionAsknStatus.equals("1"));
        askLineNumberCheckbox.setAlignmentX(Component.LEFT_ALIGNMENT);


        askLineNumberCheckbox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                optionsStorage.setOption(OPTION_ASKN, e.getStateChange() == ItemEvent.SELECTED ? "1" : "0");
            }
        });

        mainPanel.add(askLineNumberCheckbox);

        JLabel explanationLabel = new JLabel("<html><body style='width: 400px'>If you set the option to 'Ask for initial line number' a popup will appear in which you can indicate the line number for the first lb element generated, which will be written in the attribute @n. Each subsequent lb will add one to their @n value. If you disable the option, the tool will create lb elements without a @n attribute. This is the same behaviour for when no input is given in the popup.</body></html>");
        explanationLabel.setFont(fontPlain);
        explanationLabel.setBorder(BorderFactory.createEmptyBorder(10,10,30,10));
        explanationLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(explanationLabel);

        /*JSeparator sep2 = new JSeparator();
        sep2.setOrientation(SwingConstants.HORIZONTAL);
        sep2.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        sep2.setSize(new Dimension(20,20));
        *//*sep2.setSize(20,20);*//*
        sep2.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(sep2);*/

        JLabel decimalsLabel = new JLabel("On partial numbers increment: ");
        decimalsLabel.setBorder(BorderFactory.createEmptyBorder(30,10,0,0));
        mainPanel.add(decimalsLabel);
        decimalsCombobox = new JComboBox(new String[]{"Decimals", "Units"});
        decimalsCombobox.setBorder(BorderFactory.createEmptyBorder(5,0,10,0));
        decimalsCombobox.setAlignmentX(Component.LEFT_ALIGNMENT);
        decimalsCombobox.setMaximumSize(new Dimension(200,30));

        decimalsCombobox.setSelectedIndex(optionsStorage.getOption(OPTION_DECIMALS, "0").equals("dec") ? 0 : 1);


        decimalsCombobox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox<String> source = (JComboBox<String>) e.getSource();
                int selectedItem = source.getSelectedIndex();
                if (selectedItem == 0){
                    optionsStorage.setOption(OPTION_DECIMALS, "dec");
                } else {
                    optionsStorage.setOption(OPTION_DECIMALS, "unit");
                }

            }
        });

        mainPanel.add(decimalsCombobox);

        mainPanel.add(Box.createVerticalGlue());


        return mainPanel;
    }

    /**
     * @see ro.sync.exml.plugin.option.OptionPagePluginExtension#getKey()
     */
    @Override
    public String getKey() {
        return KEY;
    }





}
