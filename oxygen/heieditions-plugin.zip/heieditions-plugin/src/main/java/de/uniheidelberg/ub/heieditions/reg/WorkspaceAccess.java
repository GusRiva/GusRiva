package de.uniheidelberg.ub.heieditions.reg;

import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

public class WorkspaceAccess implements WorkspaceAccessPluginExtension {
    private StandalonePluginWorkspace workspace;
    @Override
    public void applicationStarted(StandalonePluginWorkspace pluginWorkspaceAccess) {
        this.workspace = pluginWorkspaceAccess;

    }

    @Override
    public boolean applicationClosing() {
        return true;
    }
}
