package de.uniheidelberg.ub.heieditions.pageinfo;

import org.apache.xerces.dom.ElementNSImpl;
import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.XPathException;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;
import ro.sync.exml.workspace.api.standalone.ViewComponentCustomizer;
import ro.sync.exml.workspace.api.standalone.ViewInfo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class WorkspaceAccess implements WorkspaceAccessPluginExtension {

    private StandalonePluginWorkspace workspace;
    private JTextField urlDisplay;
    private JLabel linkLabel;
    private JLabel pageLabel;
    private JLabel pageDisplay;

    @Override
    public void applicationStarted(StandalonePluginWorkspace pluginWorkspaceAccess) {
        workspace = pluginWorkspaceAccess;
        workspace.addViewComponentCustomizer(new ViewComponentCustomizer() {
            @Override
            public void customizeView(ViewInfo viewInfo) {
                if (!"PageinfoView".equals(viewInfo.getViewID())) {
                    return;
                }
                JPanel panel = new JPanel();
                panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
                panel.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
                JButton button1 = new JButton("Get Current Page");

                button1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                        String[] pageInfo = getPageInfo();
                        displayFacsimileURL(pageInfo);
                        } catch (XPathException ex) {  throw new RuntimeException(ex);   }

                    }
                });
                button1.setAlignmentX(Component.LEFT_ALIGNMENT);
                button1.setAlignmentY(Component.TOP_ALIGNMENT);

                panel.add(button1);

                linkLabel = new JLabel();
                pageLabel = new JLabel();
                pageDisplay = new JLabel();
                urlDisplay = new JTextField();

                // Remove border and make it look like a JLabel
                urlDisplay.setBorder(new EmptyBorder(0, 0, 0, 0));
                urlDisplay.setOpaque(false);
                urlDisplay.setEditable(false); // Make it non-editable
                urlDisplay.setForeground(UIManager.getColor("Label.foreground")); // Use label's text color
                urlDisplay.setBackground(UIManager.getColor("Label.background")); // Use label's background color
                urlDisplay.setFont(UIManager.getFont("Label.font")); // Use label's font


                urlDisplay.setAlignmentX(Component.LEFT_ALIGNMENT);
                urlDisplay.setAlignmentY(Component.TOP_ALIGNMENT);
                urlDisplay.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

                urlDisplay.setSize(new Dimension( urlDisplay.getPreferredSize().width, 20 ));

                // Create a context menu
                JPopupMenu contextMenu = new JPopupMenu();
                JMenuItem copyMenuItem = new JMenuItem("Copy link to clipboard");

                copyMenuItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String link = urlDisplay.getText(); // Replace with your link
                        copyToClipboard(link);
                    }
                });
                contextMenu.add(copyMenuItem);
                urlDisplay.addMouseListener(new MouseAdapter() {

                    @Override
                    public void mouseClicked(MouseEvent e) {
                        int buttonClicked = e.getButton();
                        if (buttonClicked == MouseEvent.BUTTON3){
                            contextMenu.show(e.getComponent(), e.getX(), e.getY());
                            return;
                        }
                        String labelText = urlDisplay.getText();
                        if (!labelText.startsWith("http")){return;}
                        try {
                            Desktop.getDesktop().browse(new URI(labelText));
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        } catch (URISyntaxException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                });

                panel.add(linkLabel);

                JPanel urlDisplayContainer = new JPanel();
                urlDisplayContainer.setSize(new Dimension(200,5));
                urlDisplayContainer.add(urlDisplay);
                panel.add(urlDisplayContainer);
                panel.add(pageLabel);
                panel.add(pageDisplay);
                panel.add(Box.createVerticalGlue());


                viewInfo.setComponent(panel);

            }
        });
    }

    @Override
    public boolean applicationClosing() {
        return true;
    }

    private String[] getPageInfo() throws XPathException {
        WSEditor editorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        WSXMLTextEditorPage editorPage = (WSXMLTextEditorPage) editorAccess.getCurrentPage();
        String pageNumber = "";
        String totalLines = "";
        Object[] pb = editorPage.evaluateXPath(".//preceding::pb[1]");
        if (pb.length < 1){
            return new String[]{"Can't find current page: not in a element inside a page.", pageNumber, totalLines};
        }
        ElementNSImpl pbElement = (ElementNSImpl) pb[0];
        String pbfacs = pbElement.getAttribute("facs");
        pageNumber = pbElement.getAttribute("n");
        if (pageNumber.equals("")){pageNumber = "Missing @n in pb";}
        if (pbfacs.equals("")){
            return new String[]{"The current page is missing a @facs attribute", pageNumber, totalLines};
        }
        Object[] graphic = editorPage.evaluateXPath("//surface[@xml:id='" + pbfacs.substring(1) + "']/graphic[1]");
        if (graphic.length < 1){
            return new String[]{"There is no surface element corresponding to this pb/@facs or it does not have a graphic element", pageNumber, totalLines};
        }
        ElementNSImpl graphicElement = (ElementNSImpl) graphic[0];
        String URL = graphicElement.getAttribute("url");
        if (URL.equals("")){
            return new String[]{"The corresponding graphic elements has no @url", pageNumber, totalLines};
        }

        return new String[]{URL, pageNumber, totalLines};
    };

    private void displayFacsimileURL(String[] pageInfo){
        linkLabel.setText("Link:");
        urlDisplay.setText(pageInfo[0]);
        if (pageInfo[0].startsWith("http")){
            urlDisplay.setForeground(Color.decode("#0645AD"));
        } else {
            urlDisplay.setForeground(Color.BLACK);
        }
        if (!pageInfo[1].equals("")){
            pageLabel.setText("Page:");
            pageDisplay.setText(pageInfo[1]);
        }
    }

    private static void copyToClipboard(String text) {
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection selection = new StringSelection(text);
        clipboard.setContents(selection, null);
    }
}
