package de.uniheidelberg.ub.heieditions;

import javax.swing.*;

public class Utils {
    private Utils(){}
    public static void replaceSelection(JTextArea textComponent, String newContent, int selectionStart){
        textComponent.replaceSelection(newContent);
        textComponent.setSelectionStart(selectionStart);
        textComponent.setSelectionEnd(selectionStart + newContent.length());
    }

    public static boolean isInteger(String str){
        // Regular expression to match a number (integer or floating-point)
        /*return str.matches("-?\\d+(\\.\\d+)?");*/
        return  str.matches("^\\d+$");
    }

    /**
     * @param str The string to check
     * @return true if is Number
     */
    public static boolean isNumber(String str){
        return str.matches("^\\d+(\\.\\d+)?$");
    }

    public static String addDTD(String input){
        String DTD = "<!DOCTYPE TEI [\n" +
                "<!ENTITY % heiEDITIONS_entities SYSTEM \"https://digi.ub.uni-heidelberg.de/schema/tei/heiEDITIONS/declarations/heieditions-entities.txt\">\n" +
                "%heiEDITIONS_entities; ]>\n";
        return DTD + input;
    }

    public static String normalizeTEISpace(String content) {
        /*content = content.replaceAll("<choice>[\s\n]*", "");
        content = content.replaceAll("[\s\n]*</choice>", "");*/
        content = content.replaceAll("[\s\n]{2,}", "");
        return content;
    }
}
