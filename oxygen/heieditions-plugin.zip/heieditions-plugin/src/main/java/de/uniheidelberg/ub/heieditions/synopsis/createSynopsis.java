package de.uniheidelberg.ub.heieditions.synopsis;

import java.io.File;


public class createSynopsis {

    public static void main(String[] args){
        File teiPath = new File( "/home/gustavo/Dokumente/Editionen/Iwein/EditionIwein/texts");
        File[] listOfFiles = teiPath.listFiles();

        for (int i = 0; i < listOfFiles.length; i++) {
          if (listOfFiles[i].isFile()) {
            System.out.println("File " + listOfFiles[i].getName());
          } else if (listOfFiles[i].isDirectory()) {
            System.out.println("Directory " + listOfFiles[i].getName());
          }
        }

    }
}
