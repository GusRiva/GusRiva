package de.uniheidelberg.ub.heieditions.numbering;

import de.uniheidelberg.ub.heieditions.lb.ActionLb;
import ro.sync.exml.plugin.general.GeneralPluginContext;
import ro.sync.exml.plugin.general.GeneralPluginExtension;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

public class KeyboardShortcut implements GeneralPluginExtension {

    @Override
    public void process(GeneralPluginContext context) {
        StandalonePluginWorkspace workspace = context.getPluginWorkspace();
        new ActionNumbering(workspace).performAction();
    }
}
