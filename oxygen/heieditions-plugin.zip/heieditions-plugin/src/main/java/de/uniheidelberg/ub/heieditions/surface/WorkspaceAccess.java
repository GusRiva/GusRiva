package de.uniheidelberg.ub.heieditions.surface;

import org.apache.xerces.dom.ElementNSImpl;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.XPathException;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;
import ro.sync.exml.workspace.api.standalone.ViewComponentCustomizer;
import ro.sync.exml.workspace.api.standalone.ViewInfo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WorkspaceAccess implements WorkspaceAccessPluginExtension {
    private StandalonePluginWorkspace workspace;
    private JPanel mainPanel;
    private JPanel surfacePanel;
    private ElementNSImpl surfaceElement;
    private Insets baseInsets = new Insets(3, 3, 3, 3);
    private Map<String, Color> colorScheme =
            Map.of(
                    "hc:MarginalZone", Color.gray,
                    "hc:MarginalColumn", Color.gray,
                    "hc:HorizontalLayout", Color.lightGray,
                    "hc:MainColumn", Color.darkGray,
                    "hc:TextZone", Color.darkGray
            );
    @Override
    public void applicationStarted(StandalonePluginWorkspace pluginWorkspaceAccess) {
        workspace = pluginWorkspaceAccess;
        workspace.addViewComponentCustomizer(new ViewComponentCustomizer() {
            @Override
            public void customizeView(ViewInfo viewInfo) {
                if (!"surfaceView".equals(viewInfo.getViewID())) {return;}

                mainPanel = new JPanel();
                mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

                JPanel topPanel = createButtonPanel();
                mainPanel.add(topPanel);

                viewInfo.setComponent(mainPanel);

            }
        });
    }

    @Override
    public boolean applicationClosing() {
        return true;
    }

    private JPanel createButtonPanel() {
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        JButton loadButton = new JButton("Load current surface");
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    surfaceElement = getSurface();
                    int components = mainPanel.getComponentCount();
                    for (int i = 1; i < components; i++) {
                        mainPanel.remove(1);
                    }
                    if (surfaceElement == null){
                        JPanel failedPanel = new JPanel();
                        JLabel messageLabel = new JLabel("Not inside a TEI Surface Element");
                        failedPanel.add(messageLabel);
                        mainPanel.add(failedPanel);
                        mainPanel.add(Box.createVerticalGlue());
                        mainPanel.revalidate();
                        mainPanel.repaint();
                    } else {
                        drawLayout(surfaceElement);
                    }
                } catch (XPathException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        topPanel.setAlignmentY(Component.CENTER_ALIGNMENT);
        topPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, loadButton.getPreferredSize().height + 10));
        topPanel.setBackground(Color.BLACK);
        topPanel.add(loadButton);
        return topPanel;
    }


    private void drawLayout(ElementNSImpl surfaceElement) {
        surfacePanel = new JPanel(new GridBagLayout());
        surfacePanel.setBackground(Color.WHITE);

        NodeList children = surfaceElement.getChildNodes();
        /*ArrayList<heiZone> heiZones = new ArrayList<>();*/
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeName() != "zone"){
                continue;
            }

            drawZone(node, i, 0, surfacePanel);



        }

        mainPanel.add(surfacePanel);
        mainPanel.add(Box.createVerticalGlue());
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void drawZone(Node node, int vertical, int horizontal, JPanel parentPanel) {
        if (node.getNodeName() != "zone"){
            return;
        }
        JPanel zonePanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        List<String> ana = List.of(node.getAttributes().getNamedItem("ana").getNodeValue().split("\s"));

        Color color = Color.lightGray;
        for (String key : colorScheme.keySet()) {
            if (ana.contains(key)){
                color = colorScheme.get(key);
            }
        }

        c.weighty = (ana.contains("hc:MarginalZone")  || ana.contains("hc:FloatingZone") ? 0.1 : 1);
        c.weightx = (ana.contains("hc:MarginalZone") || ana.contains("hc:MarginalColumn") ? 0.1 : 1);


        zonePanel.setBackground(color);
        c.gridx = horizontal;
        c.gridy = vertical;
        c.fill = GridBagConstraints.BOTH;
        c.insets = baseInsets;



        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            if (ana.contains("hc:HorizontalLayout")){
                drawZone(node.getChildNodes().item(i), 0, i , zonePanel );
                continue;
            }
            drawZone(node.getChildNodes().item(i), i, 0 , zonePanel );
        }


        parentPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        parentPanel.add(zonePanel, c);

    }

    private ElementNSImpl getSurface() throws XPathException {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        if (currentEditorAccess == null) {
            return null;
        }
        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        if (!(currentPage instanceof WSXMLTextEditorPage)) {
            return null;
        }
        WSXMLTextEditorPage textPage = (WSXMLTextEditorPage) currentPage;
        Object[] surfaceObjects = textPage.evaluateXPath("./ancestor-or-self::surface");

        if (surfaceObjects.length < 1){
            return null;
        };
        ArrayList<ElementNSImpl> surfaceElements = new ArrayList<>();
        for (int i = 0; i < surfaceObjects.length ; i++) {
            surfaceElements.add((ElementNSImpl) surfaceObjects[i]);
        }

        return surfaceElements.get(0);
    }

}
