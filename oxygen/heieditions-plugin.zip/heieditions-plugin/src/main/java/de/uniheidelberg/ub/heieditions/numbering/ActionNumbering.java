package de.uniheidelberg.ub.heieditions.numbering;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.AuthorDocumentController;
import ro.sync.ecss.extensions.api.ContentInterval;
import ro.sync.ecss.extensions.api.access.AuthorEditorAccess;
import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.author.WSAuthorEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.options.WSOptionsStorage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import javax.swing.text.BadLocationException;

import java.awt.*;
import java.lang.reflect.Array;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static de.uniheidelberg.ub.heieditions.Utils.*;
import static de.uniheidelberg.ub.heieditions.numbering.WorkspaceAccess.*;
import static de.uniheidelberg.ub.heieditions.numbering.WorkspaceAccess.OPTION_INCREMENT;

public class ActionNumbering implements WorskspaceAction {
    private final StandalonePluginWorkspace workspace;

    private WSOptionsStorage optionsStorage;


    public ActionNumbering(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
        this.optionsStorage = workspace.getOptionsStorage();
    }

    @Override
    public void performAction() {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);

        /* No file open */
        if (currentEditorAccess == null) {
            return;
        }

        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        /* In editor mode or author mode */
        if (!(currentPage instanceof WSXMLTextEditorPage || currentPage instanceof WSAuthorEditorPage)) {
            return;
        }

        /* Editor mode */
        if (currentPage instanceof WSXMLTextEditorPage){
            editorPageAction(currentPage, currentEditorAccess);
        }

        /*Author mode*/
        if (currentPage instanceof WSAuthorEditorPage){
            try {
                authorPageAction(currentPage, currentEditorAccess);
            } catch (BadLocationException e) {
                throw new RuntimeException(e);
            }
        }

    }

    private void authorPageAction(WSEditorPage currentPage,  WSEditor currentEditorAccess) throws BadLocationException {
        WSAuthorEditorPage textPage = (WSAuthorEditorPage) currentPage;
        AuthorAccess authorAccess = textPage.getAuthorAccess();
        AuthorEditorAccess authorEditorAccess = authorAccess.getEditorAccess();
        AuthorDocumentController documentController = authorAccess.getDocumentController();
        Component parentFrame = (Component) currentEditorAccess.getComponent();
        if (!authorEditorAccess.hasSelection()){
            messageNoSelection(parentFrame);
            return;
        }

        String[] userInput = getUserInput(parentFrame);

        if (userInput[0].equals("1")){
            return;
        }

        String element = userInput[1];
        int number = Integer.parseInt(userInput[2]);
        String selectedIncrementString = userInput[3];
        Integer selectedIncrement = Integer.valueOf(selectedIncrementString);

        int selectionBegin = authorEditorAccess.getBalancedSelectionStart();
        int selectionEnd = authorEditorAccess.getBalancedSelectionEnd();

        documentController.beginCompoundEdit();

        AuthorNode lastNode = null;
        for (int i = selectionBegin; i < selectionEnd + 1 ; i++) {
            AuthorNode node = documentController.getNodeAtOffset(i);
            if (node == lastNode){continue;}
            lastNode = node;
            String nodeName = node.getName();
            if (nodeName.equals(element)){
                documentController.setAttribute("n", new AttrValue(Integer.toString(number)), (AuthorElement) node);
                number += 1;
            }
        }

        documentController.endCompoundEdit();



    }

    private void editorPageAction( WSEditorPage currentPage,  WSEditor currentEditorAccess){
        WSXMLTextEditorPage textPage = (WSXMLTextEditorPage) currentPage;
        JTextArea textComponent = (JTextArea) textPage.getTextComponent();


        String selection = textComponent.getSelectedText();

        Component parentFrame = (Component) currentEditorAccess.getComponent();
        if (selection == null){
            messageNoSelection(parentFrame);
            return;
        }

        int selectionStart = textComponent.getSelectionStart();


        String[] userInput = getUserInput(parentFrame);

        if (userInput[0].equals("1")){
            return;
        }

        String element = userInput[1];
        String initialNumber = userInput[2];
        String selectedIncrementString = userInput[3];
        Integer selectedIncrement = Integer.valueOf(selectedIncrementString);


        String newContent = doNumberingInSelection(selection, element, initialNumber, selectedIncrement);

        replaceSelection(textComponent, newContent, selectionStart);
    }

    private String doNumberingInSelection(String selection, String element, String initialNumber, Integer selectedIncrement) {
        String regex = "<"+ element +"\\b[^>]*>";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(selection);

        StringBuffer result = new StringBuffer();

        final String[] splitNumberString = initialNumber.split("\\.");
        int unitNumber = Integer.parseInt(splitNumberString[0]);
        int decNumber = (selectedIncrement == -1 ? 0 : Integer.parseInt(splitNumberString[1]));
        int[] splitNumber = {unitNumber, decNumber};


        while (matcher.find()) {
            String match = matcher.group();
            String currentNumber = getCurrentNumberString(splitNumber, selectedIncrement);
            if (!match.contains(" n=")) {
                String updated = match.substring(0, match.length() - 1) + " n=\""+ currentNumber +"\"";
                if (match.contains("/>")){
                    updated += "/";
                }
                updated += ">";
                matcher.appendReplacement(result, updated);
            } else {
                String updated = match.replaceAll("\sn=\"[^\"]*\"", " n=\""+ currentNumber +"\"");
                matcher.appendReplacement(result, updated);
            }
            if (selectedIncrement == 1){
                splitNumber[1] += 1;
            } else {
                splitNumber[0] += 1;
            }

        }
        matcher.appendTail(result);

        String newContent = result.toString();
        return newContent;
    }

    private String[] getUserInput(Component parentFrame) {
        String[] result = new String[4];
        result[0] = "1"; /* Default failed option */

        Insets textInset = new Insets(2,2,2,2);
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.PAGE_AXIS));

        JTextField elementField = new JTextField(5);
        elementField.setText(optionsStorage.getOption(OPTION_ELEMENT, ""));
        elementField.setMargin(textInset);

        JTextField numberField = new JTextField(5);
        numberField.setText(optionsStorage.getOption(OPTION_INUMBER, ""));
        numberField.setMargin(textInset);

        inputPanel.add(new JLabel("Element:"));
        inputPanel.add(elementField);
        inputPanel.add(Box.createVerticalStrut(15)); // a spacer
        inputPanel.add(new JLabel("Initial Number:"));
        inputPanel.add(numberField);

        int input = JOptionPane.showConfirmDialog(
                parentFrame,
                inputPanel,
                "Numbering",
                JOptionPane.OK_CANCEL_OPTION);

        /* Cancel on OptionPane */
        if (input != JOptionPane.OK_OPTION) {
            return result;
        }


        String initialNumber = numberField.getText();
        String element = elementField.getText();

        if (initialNumber.equals("") || element.equals("")){
            JOptionPane.showMessageDialog(parentFrame, "Need to select at least an element and an initial number.", "Failed Info", JOptionPane.ERROR_MESSAGE);
            return result;
        }

        optionsStorage.setOption(OPTION_ELEMENT, element);

        if (!isNumber(initialNumber)){
            JOptionPane.showMessageDialog(
                    parentFrame,
                    "The initial number must be a positive number, in any of the formats:\n10\n10.0",
                    "Format error", JOptionPane.ERROR_MESSAGE);
            return result;
        }

        optionsStorage.setOption(OPTION_INUMBER, initialNumber);

        int selectedIncrement = -1;
        if (!isInteger(initialNumber)){
            JPanel inputPanel2 = new JPanel();
            JComboBox decimalsCombobox = new JComboBox(new String[]{"Units", "Decimals"});
            decimalsCombobox.setSelectedIndex(Math.abs(Integer.parseInt(optionsStorage.getOption(OPTION_INCREMENT, "-1"))));
            inputPanel2.add(decimalsCombobox);
            int decimalsInput = JOptionPane.showConfirmDialog(parentFrame, inputPanel2, "Increment decimals or units?", JOptionPane.OK_CANCEL_OPTION);
            /* Cancel the second popup */
            if (decimalsInput != JOptionPane.OK_OPTION) {
                return result;
            }
            selectedIncrement = decimalsCombobox.getSelectedIndex();
        }
        String selectedIncrementString = Integer.toString(selectedIncrement);
        optionsStorage.setOption(OPTION_INCREMENT, selectedIncrementString);

        result[0] = "0";
        result[1] = element;
        result[2] = initialNumber;
        result[3] = selectedIncrementString;
        return result;


    }

    private static void messageNoSelection(Component parentFrame) {
        JOptionPane.showMessageDialog(parentFrame, "Need to select some text.", "Failed action", JOptionPane.ERROR_MESSAGE);
    }


    private String getCurrentNumberString(int[] splitNumber, int selectedIncrement) {
        if (selectedIncrement == -1){
            return Integer.toString(splitNumber[0]);
        }
        return String.join(".", Integer.toString(splitNumber[0]), Integer.toString(splitNumber[1]));
    }


}
