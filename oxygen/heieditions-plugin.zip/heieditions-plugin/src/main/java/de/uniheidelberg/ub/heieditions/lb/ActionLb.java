package de.uniheidelberg.ub.heieditions.lb;

import de.uniheidelberg.ub.heieditions.WorskspaceAction;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.options.WSOptionsStorage;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

import javax.swing.*;
import java.awt.*;

import static de.uniheidelberg.ub.heieditions.Utils.*;
import static de.uniheidelberg.ub.heieditions.lb.Plugin.OPTION_ASKN;
import static de.uniheidelberg.ub.heieditions.lb.Plugin.OPTION_DECIMALS;

public class ActionLb implements WorskspaceAction {
    private final StandalonePluginWorkspace workspace;

    public ActionLb(StandalonePluginWorkspace workspace) {
        this.workspace = workspace;
    }
    @Override
    public void performAction() {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        WSOptionsStorage optionsStorage = workspace.getOptionsStorage();
        if (currentEditorAccess == null) {
            return;
        }
        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        if (!(currentPage instanceof WSXMLTextEditorPage)) {
            return;
        }
        WSXMLTextEditorPage textPage = (WSXMLTextEditorPage) currentPage;

        JTextArea textComponent = (JTextArea) textPage.getTextComponent();
        String selection = textComponent.getSelectedText();
        int selectionStart = textComponent.getSelectionStart();

        boolean askLineOptionSelected = optionsStorage.getOption(OPTION_ASKN, "unset").equals("1");
        String newContent;


        if (!askLineOptionSelected) {
            newContent = addLineBreaks(selection);
            replaceSelection(textComponent, newContent, selectionStart);
            return;
        }

        Component parentFrame = (Component) currentEditorAccess.getComponent();
        String initialNumber = JOptionPane.showInputDialog(parentFrame,
                "Enter Initial lb number",
                "lb - n",
                JOptionPane.PLAIN_MESSAGE);

        /* Cancel on OptionPane */
        if (initialNumber == null){
            return;
        }

        initialNumber = initialNumber.trim();

        if (initialNumber.isEmpty()) {
            newContent = addLineBreaks(selection);
            replaceSelection(textComponent, newContent, selectionStart);
            return;
        }

        if (isNumber(initialNumber)) {
            newContent = addLineBreaksAndNumber(selection, initialNumber, optionsStorage);
            replaceSelection(textComponent, newContent, selectionStart);
            return;
        }

        JOptionPane.showMessageDialog(parentFrame,
                "The @n attribute of <lb> must be a positive number, in any of the formats:\n" +
                        "10\n10.0",
                "Format error",
                JOptionPane.ERROR_MESSAGE);
    }



    private static String addLineBreaks(String context){
        String result = "<lb>";
        if (context == null) {
            return result;
        }
        return result + context.replaceAll("(\n +)", "$1<lb/>");
    }

    private static String addLineBreaksAndNumber(String context, String initialNumber, WSOptionsStorage optionStorage){
        String result = "<lb n=\""+initialNumber+"\"/>";

        if (context == null) {
            return result;
        }

        String[] lines = context.split("\n");
        StringBuilder stringBuilder = new StringBuilder();

        /* In this case, it has a point */
        if (!isInteger(initialNumber)){
            String[] splitNumber = initialNumber.split("[\\.,]");
            /*String separator = ".";
            if (initialNumber.contains(",")){
                separator = ",";
            }*/
            int leftSide = Integer.parseInt(splitNumber[0]);
            int rightSide = Integer.parseInt(splitNumber[1]);
            for (int i = 0; i < lines.length; i++) {
                if (i == 0){stringBuilder.append(lines[0]); continue;}
                String lineContent = switch (optionStorage.getOption(OPTION_DECIMALS, "dec")) {
                    case "dec" ->
                            lines[i].replaceAll("^( *)(.*)$", "$1<lb n=\"" + leftSide + "." + (rightSide + i) + "\"/>$2");
                    default ->
                            lines[i].replaceAll("^( *)(.*)$", "$1<lb n=\"" + (leftSide + i) + "." + rightSide + "\"/>$2");
                };
                stringBuilder.append("\n"+lineContent);

            }
            result += stringBuilder.toString();
            return result;
        }

        /* Integer */
        Integer initialNumberint = Integer.parseInt(initialNumber);

        for (int i = 0; i < lines.length; i++) {
            if (i == 0){stringBuilder.append(lines[0]); continue;}
            String lineContent = lines[i].replaceAll("^( *)(.*)$", "$1<lb n=\""+ (initialNumberint + i) +"\"/>$2");
            stringBuilder.append("\n"+lineContent);
        }
        result += stringBuilder.toString();
        return result;
    }

}
