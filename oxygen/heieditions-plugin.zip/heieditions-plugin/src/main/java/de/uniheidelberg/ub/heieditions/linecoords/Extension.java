package de.uniheidelberg.ub.heieditions.linecoords;

import ro.sync.exml.plugin.general.GeneralPluginContext;
import ro.sync.exml.plugin.general.GeneralPluginExtension;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;

public class Extension implements  GeneralPluginExtension {
    public void process(GeneralPluginContext context){
        StandalonePluginWorkspace workspace = context.getPluginWorkspace();
        new ActionLineCoords(workspace).performAction();
    }
}
