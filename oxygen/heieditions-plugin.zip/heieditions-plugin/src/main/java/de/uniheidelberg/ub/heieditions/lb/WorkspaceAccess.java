package de.uniheidelberg.ub.heieditions.lb;

import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.options.WSOptionsStorage;
import ro.sync.exml.workspace.api.standalone.*;

import static de.uniheidelberg.ub.heieditions.lb.Plugin.OPTION_ASKN;
import static de.uniheidelberg.ub.heieditions.lb.Plugin.OPTION_DECIMALS;

public class WorkspaceAccess implements WorkspaceAccessPluginExtension {
    private StandalonePluginWorkspace workspace;
    @Override
    public void applicationStarted(final StandalonePluginWorkspace pluginWorkspaceAccess) {
        this.workspace = pluginWorkspaceAccess;

//        PREFERENCES OPTION INIT
        WSOptionsStorage optionsStorage = workspace.getOptionsStorage();

        String optionAskStatus = optionsStorage.getOption(OPTION_ASKN, "unset");
        if (optionAskStatus.equals("unset")){optionsStorage.setOption(OPTION_ASKN, "1");}
        String optionDecStatus = optionsStorage.getOption(OPTION_DECIMALS, "unset");
        if (optionDecStatus.equals("unset")){optionsStorage.setOption(OPTION_DECIMALS, "dec");}

    }

    @Override
    public boolean applicationClosing() {
        return true;
    }
}
