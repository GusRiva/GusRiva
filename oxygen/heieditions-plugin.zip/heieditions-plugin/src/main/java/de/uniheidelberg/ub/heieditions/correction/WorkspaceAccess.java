package de.uniheidelberg.ub.heieditions.correction;



import ro.sync.exml.plugin.workspace.WorkspaceAccessPluginExtension;
import ro.sync.exml.workspace.api.PluginWorkspace;
import ro.sync.exml.workspace.api.editor.WSEditor;
import ro.sync.exml.workspace.api.editor.page.WSEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;
import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextNodeRange;
import ro.sync.exml.workspace.api.editor.page.text.xml.XPathException;
import ro.sync.exml.workspace.api.standalone.StandalonePluginWorkspace;
import ro.sync.exml.workspace.api.standalone.ViewComponentCustomizer;
import ro.sync.exml.workspace.api.standalone.ViewInfo;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static de.uniheidelberg.ub.heieditions.Utils.replaceSelection;
import static javax.swing.JEditorPane.HONOR_DISPLAY_PROPERTIES;

public class WorkspaceAccess implements WorkspaceAccessPluginExtension {
    private static StandalonePluginWorkspace workspace;
    private static final int vgap = 10;
    String[] panels = {"Original", "Regularisation"};
    @Override
    public void applicationStarted(StandalonePluginWorkspace pluginWorkspaceAccess) {
        workspace = pluginWorkspaceAccess;
        workspace.addViewComponentCustomizer(new ViewComponentCustomizer() {
            @Override
            public void customizeView(ViewInfo viewInfo) {
                if (!"CorrectionView".equals(viewInfo.getViewID())) {
                    return;
                }


                /*Background Panel*/
                JPanel backPanel = new JPanel();
                backPanel.setLayout(new BoxLayout(backPanel, BoxLayout.Y_AXIS));
                backPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

                Font font = new JLabel().getFont();
                FontMetrics fontMetrics = new JLabel().getFontMetrics(font);
                int charWidth = fontMetrics.charWidth('X');
                int maxWidth = charWidth * 80;

                /*ActionListener reloadCurrentElement = new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println("Timer executed");
                    }
                };
                int delay = 5000;
                Timer timer = new Timer(delay, reloadCurrentElement);
                timer.start();*/

                JButton loadButton = new JButton("Load");
                backPanel.add(loadButton);

                loadButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int totalComp = backPanel.getComponentCount();
                        for (int i = 1; i < totalComp; i++) {
                            backPanel.remove( totalComp - i);
                        }
                        EditableContent editableContent = null;
                        try {
                            editableContent = getEditableContent();
                        } catch (XPathException ex) {
                            throw new RuntimeException(ex);
                        } catch (BadLocationException ex) {
                            throw new RuntimeException(ex);
                        }
                        if (editableContent == null){
                            return;
                        }






                        for (String panelType: panels){
                            /*contructDisplayPanel(backPanel, elementString, maxWidth, panelType);*/
                            addLabelType(panelType, backPanel);
                            displayPane(backPanel, editableContent, maxWidth, panelType);
                             }

                        backPanel.add(Box.createVerticalGlue());
                        backPanel.revalidate();
                        backPanel.repaint();
                    }
                });



                viewInfo.setComponent(backPanel);
            }
        });
    }

    private static void addLabelType(String panelType, JPanel backPanel) {
        JPanel labelPanel = new JPanel();
        labelPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        labelPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel originalLabel = new JLabel(panelType);
        labelPanel.add(originalLabel);
        labelPanel.setPreferredSize(new Dimension(labelPanel.getPreferredSize().width, originalLabel.getPreferredSize().height + vgap * 2));
        labelPanel.setMaximumSize(new Dimension(labelPanel.getMaximumSize().width, originalLabel.getPreferredSize().height + vgap * 2 + 5));
        backPanel.add(labelPanel);
    }

    EditableContent getEditableContent() throws XPathException, BadLocationException {
        WSEditor currentEditorAccess = workspace.getCurrentEditorAccess(PluginWorkspace.MAIN_EDITING_AREA);
        if (currentEditorAccess == null) {
            return null;
        }
        WSEditorPage currentPage = currentEditorAccess.getCurrentPage();
        if (!(currentPage instanceof WSXMLTextEditorPage)) {
            return null;
        }
        WSXMLTextEditorPage textPage = (WSXMLTextEditorPage) currentPage;
        WSXMLTextNodeRange[] range = textPage.findElementsByXPath("(./ancestor-or-self::l| //ancestor-or-self::ab)[1]");
        if (range.length == 0){
            return null;
        }



        int startOffset = textPage.getOffsetOfLineStart(range[0].getStartLine()) + range[0].getStartColumn() -1;

        int endOffset = textPage.getOffsetOfLineStart(range[0].getEndLine()) + range[0].getEndColumn() -1;

        String fullElement = textPage.getDocument().getText(startOffset, endOffset - startOffset);
        EditableContent editableContent = new EditableContent(fullElement, startOffset,endOffset, textPage);




        return editableContent;
    }

    private static void displayPane(JPanel backPanel, EditableContent editableContent, int maxWidth, String type) {


        /*JPanel originalPanel = new JPanel();
        originalPanel.setLayout(new WrappingFlowLayout(FlowLayout.LEFT, 10, vgap));
        originalPanel.setAlignmentX(Component.CENTER_ALIGNMENT);*/

        JPanel panelContent = editableContent.getDisplay(type);

        /*ArrayList<JEditorPane> panelContent = null;
        panelContent = getContent(editableContent, type);

        if (panelContent == null){return;}

        for (int j = 0; j < panelContent.size(); j++) {
            JEditorPane wordLabel = panelContent.get(j);
            originalPanel.add(wordLabel);
        }*/


        JScrollPane scrollPane = new JScrollPane(panelContent);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        // Calculate the preferred height for the scroll pane based on four lines of labels
        int lineHeight = panelContent.getComponent(0).getPreferredSize().height + 12;
        int preferredHeight = lineHeight * 4;
        scrollPane.setPreferredSize(new Dimension(maxWidth, preferredHeight));
        scrollPane.setMaximumSize(new Dimension(maxWidth, preferredHeight));


        backPanel.add(scrollPane);
    }


    private static void contructDisplayPanel(JPanel backPanel, String fullElement, int maxWidth, String type) {
        JPanel labelPanel = new JPanel();
        labelPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        labelPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel originalLabel = new JLabel(type);
        labelPanel.add(originalLabel);
        labelPanel.setPreferredSize(new Dimension(labelPanel.getPreferredSize().width, originalLabel.getPreferredSize().height + vgap * 2));
        labelPanel.setMaximumSize(new Dimension(labelPanel.getMaximumSize().width, originalLabel.getPreferredSize().height + vgap * 2 + 5));
        backPanel.add(labelPanel);

        JPanel originalPanel = new JPanel();
        originalPanel.setLayout(new WrappingFlowLayout(FlowLayout.LEFT, 10, vgap));
        originalPanel.setAlignmentX(Component.CENTER_ALIGNMENT);


        ArrayList<JEditorPane> panelContent = null;
        panelContent = getContent(fullElement, type);

        if (panelContent == null){return;}

        for (int j = 0; j < panelContent.size(); j++) {
            JEditorPane wordLabel = panelContent.get(j);
            originalPanel.add(wordLabel);
        }


        JScrollPane scrollPane = new JScrollPane(originalPanel);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        // Calculate the preferred height for the scroll pane based on four lines of labels
        int lineHeight = originalPanel.getComponent(0).getPreferredSize().height + 12;
        int preferredHeight = lineHeight * 4;
        scrollPane.setPreferredSize(new Dimension(maxWidth, preferredHeight));
        scrollPane.setMaximumSize(new Dimension(maxWidth, preferredHeight));


        backPanel.add(scrollPane);
    }

    private static ArrayList<JEditorPane> getContent(String fullElement, String type) {
        ArrayList<JEditorPane> jLabels = new ArrayList<>();


        ArrayList<regToken> regTokens = getTokens(fullElement);

        if (regTokens.size() == 0){
            return null;
        }
        /*System.out.println(regTokens);*/
        for (int i = 0; i < regTokens.size(); i++) {
            JEditorPane tokenLabel =new JEditorPane();
            tokenLabel.setContentType("text/html");
            tokenLabel.setEditable(false);
            tokenLabel.setBorder(BorderFactory.createEmptyBorder());
            tokenLabel.setBackground(null);
            tokenLabel.putClientProperty(HONOR_DISPLAY_PROPERTIES, true);
            if (type == "Regularisation"){
                tokenLabel.setText("<html>" + regTokens.get(i).getHtmlReg() + "</html>");
            } else {
                tokenLabel.setText("<html>" + regTokens.get(i).getHtmlOrig() + "</html>");
            }


            jLabels.add(tokenLabel);
        }



        return jLabels;
    }

    /*private static ArrayList<regToken> getTokens(String fullElement) throws ParserConfigurationException, IOException, SAXException {
                String xmlFragment = addDTD(fullElement);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        *//*builder.setEntityResolver(new heiEditionsEntityResolver());*//*
        Document doc = builder.parse(new InputSource(new StringReader(xmlFragment)));

        NodeList wElements = doc.getElementsByTagName("w");


        ArrayList<regToken> result = new ArrayList<regToken>();
        for (int i = 0; i < wElements.getLength(); i++) {
            Element wElement = (Element) wElements.item(i);
            String content = wElement.getTextContent();
            result.add(new regToken(content));
        }
        return result;
    }*/

    private static ArrayList<regToken> getTokens(String fullElements) {
        ArrayList<regToken> result = new ArrayList<>();
        String regexW = "<w(\\b[^>]*)>(.*?(?=</w))";
        Pattern pattern = Pattern.compile(regexW, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(fullElements);


        while (matcher.find()) {
            String attr = matcher.group(1);
            String content = matcher.group(2);
            int startContent = matcher.start();
            int endW = matcher.end(1) + 1;
            int endContent = matcher.end();
            ArrayList<Integer> deleteIntegers = integersInRange(startContent, endW);
            /*System.out.println("Start content");
            System.out.println(startContent);
            System.out.println("End W tag");
            System.out.println(endW);
            System.out.println("Range");
            System.out.println(deleteIntegers);*/
            result.add(new regToken(content));
        }




        return result;
    }

    private static ArrayList<Integer> integersInRange(int start, int end){
        ArrayList<Integer> result = new ArrayList<>();
        for (int i = start; i <= end ; i++) {
            result.add(i);
        }
        return result;
    }



    @Override
    public boolean applicationClosing() {
        return true;
    }

    static class WrappingFlowLayout extends FlowLayout {
    public WrappingFlowLayout(int align, int hgap, int vgap) {
        super(align, hgap, vgap);
    }

    @Override
    public Dimension preferredLayoutSize(Container target) {
        synchronized (target.getTreeLock()) {
            int targetWidth = target.getSize().width;

            if (target.getComponentCount() == 0) {
                return super.preferredLayoutSize(target);
            }

            Component firstComponent = target.getComponent(0);
            Dimension preferredSize = firstComponent.getPreferredSize();

            int maxComponentWidth = preferredSize.width;
            int totalHeight = preferredSize.height;
            int rowWidth = maxComponentWidth;
            int rows = 1;

            for (int i = 1; i < target.getComponentCount(); i++) {
                Component component = target.getComponent(i);
                preferredSize = component.getPreferredSize();

                if (rowWidth + preferredSize.width + getHgap() <= targetWidth) {
                    rowWidth += preferredSize.width + getHgap();
                    maxComponentWidth = Math.max(maxComponentWidth, preferredSize.width);
                } else {
                    rowWidth = preferredSize.width;
                    totalHeight += preferredSize.height + getVgap();
                    rows++;
                }
            }

            totalHeight += getVgap() * (rows - 1);

            return new Dimension(Math.min(targetWidth, maxComponentWidth), totalHeight);
        }
    }
}
}
