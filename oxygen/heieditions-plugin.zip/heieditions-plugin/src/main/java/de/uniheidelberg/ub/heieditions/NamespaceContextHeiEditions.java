package de.uniheidelberg.ub.heieditions;

import javax.xml.namespace.NamespaceContext;
import java.util.Iterator;

public class NamespaceContextHeiEditions implements NamespaceContext {
    @Override
    public String getNamespaceURI(String prefix) {
        if ("tei".equals(prefix)) {
            return "http://www.tei-c.org/ns/1.0";
        }
        if ("mets".equals(prefix)) {
            return "http://www.loc.gov/METS/";
        }
        if ("xlink".equals(prefix)) {
            return "http://www.w3.org/1999/xlink";
        }
        if ("page".equals(prefix)) {
            return "http://schema.primaresearch.org/PAGE/gts/pagecontent/2019-07-15";
        }
        return null;
    }

    @Override
    public String getPrefix(String namespaceURI) {
        if ("http://www.tei-c.org/ns/1.0".equals(namespaceURI)) {
            return "tei";
        }
        if ("http://www.loc.gov/METS/".equals(namespaceURI)) {
            return "mets";
        }
        if ("http://www.w3.org/1999/xlink".equals(namespaceURI)) {
            return "xlink";
        }
        if ("http://schema.primaresearch.org/PAGE/gts/pagecontent/2019-07-15".equals(namespaceURI)) {
            return "page";
        }
        return null;
    }

    @Override
    public Iterator<String> getPrefixes(String namespaceURI) {
        return null;
    }
}



