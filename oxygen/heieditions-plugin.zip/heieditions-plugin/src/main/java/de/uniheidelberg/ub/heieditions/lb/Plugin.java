package de.uniheidelberg.ub.heieditions.lb;

import ro.sync.exml.plugin.PluginDescriptor;


public class Plugin extends ro.sync.exml.plugin.Plugin {
    private static Plugin instance = null;

    public static String OPTION_ASKN = "HEIED_LB_ASKN"; /* Also create @ attribute. 0 = no; 1 = yes*/
    public static String OPTION_DECIMALS = "HEIED_LB_DECIMALS"; /* Use decimals or units increasing in point float numbers: unit | dec */

    public Plugin(PluginDescriptor pluginDescriptor) {
        super(pluginDescriptor);
        if (instance != null) {
              throw new IllegalStateException("Already instantiated!");
            }
            instance = this;
    }
    public static Plugin getInstance(){
        return  instance;
    }

}
