package de.uniheidelberg.ub.heieditions.correction;

import ro.sync.exml.workspace.api.editor.page.text.xml.WSXMLTextEditorPage;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static de.uniheidelberg.ub.heieditions.Utils.replaceSelection;

public class EditableContent {
    private final String elementString;
    private final int startOffset;
    private final int endOffset;
    private final JTextArea textComponent;
    private final WSXMLTextEditorPage textPage;
    private ArrayList<Integer> availableOffsets;
    private final HashMap<String, ArrayList<Integer>> origRegOffsets;


    public EditableContent(String elementString, int startOffset, int endOffset, WSXMLTextEditorPage textPage) {
        this.elementString = elementString;
        this.startOffset = startOffset;
        this.endOffset = endOffset;
        this.availableOffsets = calculateAvailableOffsets();
        this.origRegOffsets = calculateOrigOffsets();
        this.textPage = textPage;
        this.textComponent = (JTextArea) textPage.getTextComponent();
    }



    public int getLenght() {
        return this.endOffset - this.startOffset;
    }

    public JPanel getDisplay(String type) {
        JPanel displayPanel = new JPanel();
        JTextPane contentPane = new JTextPane();
        contentPane.setEditable(false);
        /*contentPane.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));*/
        StyledDocument doc = contentPane.getStyledDocument();

        SimpleAttributeSet normalStyle = new SimpleAttributeSet();
        SimpleAttributeSet underlineStyle = new SimpleAttributeSet();
        StyleConstants.setFontSize(normalStyle, 16);
        StyleConstants.setFontSize(underlineStyle, 16);
        StyleConstants.setUnderline(underlineStyle, true);
        StyleConstants.setForeground(underlineStyle, Color.darkGray);



        HashMap displayFragment = displayFragment(type);
        HashMap<String, ArrayList> specialOffsets = (HashMap) displayFragment.get("specialOffsets");
        /*System.out.println(type);
        System.out.println(specialOffsets.get(type));
        System.out.println(specialOffsets);*/
        String input = (String) displayFragment.get("string");

        /* Entities */
        String targetRegex = "&\\w+?;";
        String replacement = "o";
        ArrayList<Integer> changeOffsets = new ArrayList<>();
        ArrayList<Integer> changeOffsetsLength = new ArrayList<>();

        Pattern pattern = Pattern.compile(targetRegex, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(input);

        StringBuilder displayTextBuilder = new StringBuilder();
        int countOffset = 0;

         while (matcher.find()) {
             int matchLength = matcher.end() - matcher.start() - 1;
             changeOffsetsLength.add(matchLength);
             displayTextBuilder.append(input, countOffset, matcher.start()); // Append text before match
             changeOffsets.add(displayTextBuilder.length()); // Store offset where change occurred
             displayTextBuilder.append(replacement); //
             countOffset = matcher.end(); // Move offset past the match
        }
        displayTextBuilder.append(input.substring(countOffset));
        String displayText = displayTextBuilder.toString();

        /* Deal with the entities for the orig/reg in the display fragment as well*/

        try {
            doc.insertString(doc.getLength(), displayText, normalStyle);

            ArrayList offsets = specialOffsets.get(type);
            if (!(offsets == null)){
                for (int i = 0; i < offsets.size(); i++) {
                    doc.setCharacterAttributes((Integer) offsets.get(i),1, underlineStyle, false);
                }
            }


            /* Underline
            doc.setCharacterAttributes(5,1, underlineStyle, false);
            doc.setCharacterAttributes(9,5, underlineStyle, false);*/
        } catch (BadLocationException e) {
            e.printStackTrace();
        }

        contentPane.addCaretListener(e -> {
            int start = contentPane.getSelectionStart();
            int end = contentPane.getSelectionEnd();

            if (start == end) {
                return;
            }

            ArrayList<Integer> selectedOffsets = new ArrayList<>();
            selectedOffsets.add(start);
            selectedOffsets.add(end);
            System.out.println("selected Offsets" + selectedOffsets);

            /* Change selected offsets based on resolved entities */
            List<Integer> modifiedOffsets = new ArrayList<>();
            int changeIndex = 0;
            int offsetIncrease = 0;

            for (int i = 0; i < selectedOffsets.size(); i++) {
                while (changeIndex < changeOffsets.size() &&
                        changeOffsets.get(changeIndex) < selectedOffsets.get(i) ) {
                    offsetIncrease += changeOffsetsLength.get(changeIndex);
                    changeIndex ++;
                }
                Integer modifiedOffset = selectedOffsets.get(i) + offsetIncrease;
                modifiedOffsets.add(modifiedOffset);
            }


            start = modifiedOffsets.get(0);
            end = modifiedOffsets.get(1);

            int length = end - start;


            /* HERE I'M MISSING THE ORIG-REG ETC*/
/*            boolean allSelectedValid = true;
            for (Integer selectedOffset: selectedOffsets) {
                if (!this.availableOffsets.contains(selectedOffset)){
                    allSelectedValid = false;
                    break;
                }
            }*/

            System.out.println("Modified Offsets: " + modifiedOffsets);
            System.out.println("Available Offsets: "+ availableOffsets);

            /*String compositeString = "";
            for (int i = 0; i < availableOffsets.size() ; i++) {
                int characterOffset = this.startOffset + this.availableOffsets.get(i);
                textPage.select(characterOffset, characterOffset + 1);
                String characterAtSelection = textPage.
                        getSelectedText();
                System.out.println(this.availableOffsets.get(i) + " : " + characterAtSelection);
                compositeString += characterAtSelection;
            }
            System.out.println(compositeString);*/



            int netOffsetStart = this.startOffset + this.availableOffsets.get(start);
            int netOffsetEnd = netOffsetStart + length;


            textPage.select(netOffsetStart, netOffsetEnd);
            System.out.println("textPage: "+ textPage);
            replaceSelection(textComponent, "<choice><orig>" + textPage.getSelectedText() + "</orig><reg></reg></choice>", netOffsetStart);


        });


        displayPanel.add(contentPane);
        return displayPanel;
    }

    public ArrayList<Integer> getAvailableOffsets(){
        return this.availableOffsets;
    }

    private static ArrayList<Integer> integersInRange(int start, int end){
        ArrayList<Integer> result = new ArrayList<>();
        for (int i = start; i <= end ; i++) {
            result.add(i);
        }
        return result;
    }

    private HashMap<String, ArrayList<Integer>> calculateOrigOffsets(){
        HashMap<String, ArrayList<Integer>> result = new HashMap<>();
        result.put("Original", new ArrayList<>());
        result.put("Regularisation", new ArrayList<>());

        String origRegex = "<orig>(.*?)</orig>";
        Pattern pattern = Pattern.compile(origRegex, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(this.elementString);
        while (matcher.find()) {
            int startContent = matcher.start(1);
            int endContent = matcher.end(1);
            ArrayList<Integer> matchedOffsets = integersInRange(startContent , endContent - 1);
            result.get("Original").addAll(matchedOffsets);
        }

        String regRegex = "<reg>(.*?)</reg>";
        Pattern pattern2 = Pattern.compile(regRegex, Pattern.DOTALL);
        Matcher matcher2 = pattern2.matcher(this.elementString);
        while (matcher2.find()) {
            int startContent = matcher2.start(1);
            int endContent = matcher2.end(1);
            ArrayList<Integer> matchedOffsets = integersInRange(startContent , endContent - 1);
            result.get("Regularisation").addAll(matchedOffsets);
        }

        return result;
    };

    private ArrayList<Integer> calculateAvailableOffsets(){
        ArrayList<Integer> allOffsets = integersInRange(0, this.getLenght() - 1);
        ArrayList<Integer> result = new ArrayList<>(allOffsets);

        String amRegex = "<am>.*?</am>";
        result = filterByRegex(amRegex, result);

        /*String regRegex = "<reg>.*?</reg>";
        result = filterByRegex(regRegex, result);

        String origRegex = "<orig>.*?</orig>";
        result = filterByRegex(origRegex, result);*/

        String whitespaceRegex = "(?<!<c)>[\\s\n]+<(?!/c>)";
        result = filterByRegex(whitespaceRegex, result);

        String tagRegex = "</?\\w+\\b[^>]*>";
        result = filterByRegex(tagRegex, result);

        return result;
    }



    private HashMap displayFragment(String type){
        StringBuilder resultString = new StringBuilder();
        ArrayList<Integer> offsets = this.availableOffsets;
        HashMap<String, ArrayList> specialOffsets = new HashMap();
        specialOffsets.put("Original", new ArrayList<>());
        for (int i = 0; i < offsets.size(); i++) {
            int offset = offsets.get(i);
            if (offset >= 0 && offset < this.elementString.length()) {
                if (this.origRegOffsets.get(type).contains(offset)){
                    specialOffsets.get("Original").add(i);
                };
                resultString.append(this.elementString.charAt(offset));
            }
        }

        String newString = resultString.toString();
        HashMap result = new HashMap();
        result.put("string", newString);
        result.put("specialOffsets", specialOffsets);
        return result;
    }




    private ArrayList<Integer> filterByRegex(String regex, ArrayList availableOffsets){
        ArrayList<Integer> result = new ArrayList<>(availableOffsets);
        ArrayList<Integer> filter = new ArrayList<>();
        Pattern pattern = Pattern.compile(regex, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(this.elementString);

        while (matcher.find()) {
            int startContent = matcher.start();
            int endContent = matcher.end();
            ArrayList<Integer> matchedOffsets = integersInRange(startContent , endContent - 1);
            filter.addAll(matchedOffsets);
        }
        result.removeAll(filter);
        return result;

    }



}
